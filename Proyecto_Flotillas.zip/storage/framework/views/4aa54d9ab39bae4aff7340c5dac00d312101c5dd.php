<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title><?php echo e($nombre); ?></title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <link href="<?php echo e(asset('css/reporte.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div id="header">
        <div class="wrap">
            <img id="logo" alt="image" src="<?php echo e(asset('img/logo_reporte.png')); ?>" width="200" height="110">
            <h1 id="logo"><a href="#"><?php echo e($nombre); ?></a></h1>
            <?php
                date_default_timezone_set('America/Mexico_City');
                $fecha = date('d-m-Y H:i:s');
            ?>
            <p><br />Fecha de emisión del reporte: <?php echo e($fecha); ?> </p>
        </div>
    </div>
    <div class='wrap'>
        <table class="table table-striped mt-2">
            <thead style="background-color:#000000">
                <th style="color:#fff;">Cliente</th>
                <th style="color:#fff;">Marca</th>
                <th style="color:#fff;">Año Unidad</th>
                <th style="color:#fff;">Placas</th>
                <th style="color:#fff;">Tipo Unidad</th>
                <th style="color:#fff;">Razon Social</th>
                <th style="color:#fff;">Fecha Ultima Fumigacion</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($unidade->cliente); ?> </td>
                        <td><?php echo e($unidade->marca); ?> </td>
                        <td><?php echo e($unidade->añounidad); ?> </td>
                        <td><?php echo e($unidade->placas); ?> </td>
                        <td><?php echo e($unidade->tipounidad); ?> </td>
                        <td><?php echo e($unidade->razonsocialunidad); ?> </td>
                        <td><?php echo e($unidade->lapsofumigacion); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
    integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
    integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
</script>

</html>
<?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/pdf/ReporteFumigaciones.blade.php ENDPATH**/ ?>