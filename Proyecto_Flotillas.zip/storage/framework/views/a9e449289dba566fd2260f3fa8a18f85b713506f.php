<?php $__env->startSection('title'); ?>
    Operadores
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Operadores de : <?php echo e($usuario); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="card-body">
                    <a class="btn btn-danger" href="<?php echo e(route('clientes.index')); ?>">Regresar</a>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-warning" href="<?php echo e(route('operadores.crear', $usuario)); ?>">Nuevo</a>
                            <table class="table table-striped mt-2" id="tabla">
                                <a class="btn btn-success" href="<?php echo e(route('operadores.export', $usuario)); ?>"><i
                                        class="fas fa-file-excel"></i></a>
                                <input type="text" class="form-control pull-right" style="width:20%" id="search"
                                    placeholder="Buscar....">
                                <thead style="background-color:#6777ef">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Nombre Operador</th>
                                    <th style="color:#fff;">Informacion</th>
                                    <th style="color:#fff;">Estado Vencimiento Medico</th>
                                    <th style="color:#fff;">Estado Vencimiento Licencia</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operadore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($operadore->id); ?></td>
                                            <td><?php echo e($operadore->nombreoperador); ?></td>
                                            
                                            <td>
                                                <button type="button" class="btn btn-primary"
                                                    onclick="$('#<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                    Detalles
                                                </button>
                                            </td>
                                            
                                            <td>
                                                
                                                <?php
                                                    /* FECHA LICENCIA */
                                                    $vencimiento_dia = substr($operadore->fechavencimientomedico, 8, 2);
                                                    $vencimiento_mes = substr($operadore->fechavencimientomedico, 5, 2);
                                                    $vencimiento_año = substr($operadore->fechavencimientomedico, 0, 4);
                                                    /* FECHA ACTUAL */
                                                    $año_actual = date('Y');
                                                    $mes_actual = date('n');
                                                    $dia_actual = date('d');
                                                    /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                    $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                    /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                    $uno = 'nulo';
                                                    $calcular = 0;
                                                    if ($diferencia_año >= 1) {
                                                        $meses = $diferencia_año * 12 + 12;
                                                        $operacion_1 = $meses - (int) $mes_actual;
                                                        $operacion_2 = 12 - (int) $vencimiento_mes;
                                                        $operacion_3 = $operacion_1 - $operacion_2;
                                                        $meses = $operacion_3;
                                                    } else {
                                                        $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                    }
                                                    if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                        $uno = 'uno';
                                                        $calcular = 0;
                                                    } else {
                                                        $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                        $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                        $calcular = $direstantes + (int) $vencimiento_dia;
                                                    }
                                                    /* CALCULO DE DIAS EXACTOS */
                                                    $dias_exactos = 0;
                                                    $contador_1 = 0;
                                                    $contador_2 = 0;
                                                    $cuenta_mes = $mes_actual;
                                                    $operacion_1 = 0;
                                                    $mes_contador = 0;
                                                    for ($i = 0; $i <= $meses; $i++) {
                                                        if ($uno == 'uno') {
                                                            $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                            $i = $meses + 1;
                                                        } else {
                                                            if ($contador_1 == 0) {
                                                                $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                $dias_exactos = $dias_exactos + $operacion_2;
                                                                $contador_1 = 1;
                                                            } else {
                                                                if ($i == $meses) {
                                                                    $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                } else {
                                                                    $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                    $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                    $mes_contador = $mes_contador + 1;
                                                                }
                                                            }
                                                            if ($cuenta_mes == 12) {
                                                                $contador_2 = $contador_2 + 1;
                                                                $cuenta_mes = 1;
                                                            } else {
                                                                $cuenta_mes = $cuenta_mes + 1;
                                                            }
                                                        }
                                                    }
                                                    /* CALCULO DE MESES EXACTOS */

                                                    $dias_resto = $calcular;
                                                    $opc = 2;
                                                    for ($i = 0; $i <= $opc; $i++) {
                                                        if ($calcular >= 30) {
                                                            $mes_contador = $mes_contador + 1;
                                                            $calcular = $calcular - 29;
                                                        }
                                                    }
                                                ?>
                                                
                                                
                                                <h5>
                                                    <?php if($mes_contador >= 9): ?>
                                                        <span class="badge badge-primary"
                                                            onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($mes_contador); ?> meses
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                        <span class="badge badge-success"
                                                            onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($mes_contador); ?> meses
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                        <span class="badge badge-warning"
                                                            onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($mes_contador); ?> meses
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                        <?php if($calcular == 0): ?>
                                                            <span class="badge badge-danger"
                                                                onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                                Expira en:
                                                                <?php echo e($mes_contador); ?> mes
                                                            </span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger"
                                                                onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                                Expira en:
                                                                <?php echo e($mes_contador); ?> mes y <?php echo e($calcular); ?> dias
                                                            </span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($dias_exactos); ?> dias
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($dias_exactos); ?> dias
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            MEDICO
                                                            <br> EXPIRADO
                                                        </span>
                                                    <?php endif; ?>
                                                </h5>
                                            </td>
                                            
                                            <td>
                                                
                                                <?php
                                                    /* FECHA LICENCIA */
                                                    $vencimiento_dia = substr($operadore->fechavencimientolicencia, 8, 2);
                                                    $vencimiento_mes = substr($operadore->fechavencimientolicencia, 5, 2);
                                                    $vencimiento_año = substr($operadore->fechavencimientolicencia, 0, 4);
                                                    /* FECHA ACTUAL */
                                                    $año_actual = date('Y');
                                                    $mes_actual = date('n');
                                                    $dia_actual = date('d');
                                                    /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                    $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                    /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                    $uno = 'nulo';
                                                    $calcular = 0;
                                                    if ($diferencia_año >= 1) {
                                                        $meses = $diferencia_año * 12 + 12;
                                                        $operacion_1 = $meses - (int) $mes_actual;
                                                        $operacion_2 = 12 - (int) $vencimiento_mes;
                                                        $operacion_3 = $operacion_1 - $operacion_2;
                                                        $meses = $operacion_3;
                                                    } else {
                                                        $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                    }
                                                    if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                        $uno = 'uno';
                                                        $calcular = 0;
                                                    } else {
                                                        $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                        $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                        $calcular = $direstantes + (int) $vencimiento_dia;
                                                    }
                                                    /* CALCULO DE DIAS EXACTOS */
                                                    $dias_exactos = 0;
                                                    $contador_1 = 0;
                                                    $contador_2 = 0;
                                                    $cuenta_mes = $mes_actual;
                                                    $operacion_1 = 0;
                                                    $mes_contador = 0;
                                                    for ($i = 0; $i <= $meses; $i++) {
                                                        if ($uno == 'uno') {
                                                            $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                            $i = $meses + 1;
                                                        } else {
                                                            if ($contador_1 == 0) {
                                                                $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                $dias_exactos = $dias_exactos + $operacion_2;
                                                                $contador_1 = 1;
                                                            } else {
                                                                if ($i == $meses) {
                                                                    $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                } else {
                                                                    $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                    $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                    $mes_contador = $mes_contador + 1;
                                                                }
                                                            }
                                                            if ($cuenta_mes == 12) {
                                                                $contador_2 = $contador_2 + 1;
                                                                $cuenta_mes = 1;
                                                            } else {
                                                                $cuenta_mes = $cuenta_mes + 1;
                                                            }
                                                        }
                                                    }
                                                    /* CALCULO DE MESES EXACTOS */

                                                    $dias_resto = $calcular;
                                                    $opc = 2;
                                                    for ($i = 0; $i <= $opc; $i++) {
                                                        if ($calcular >= 30) {
                                                            $mes_contador = $mes_contador + 1;
                                                            $calcular = $calcular - 29;
                                                        }
                                                    }
                                                ?>
                                                
                                                
                                                <h5>
                                                    <?php if($mes_contador >= 9): ?>
                                                        <span class="badge badge-primary"
                                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($mes_contador); ?> meses
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                        <span class="badge badge-success"
                                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($mes_contador); ?> meses
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                        <span class="badge badge-warning"
                                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($mes_contador); ?> meses
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                        <?php if($calcular == 0): ?>
                                                            <span class="badge badge-danger"
                                                                onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                                Expira en:
                                                                <?php echo e($mes_contador); ?> mes y <?php echo e($calcular); ?> dias
                                                            </span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger"
                                                                onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                                Expira en:
                                                                <?php echo e($mes_contador); ?> mes
                                                            </span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($dias_exactos); ?> dias
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            Expira en:
                                                            <?php echo e($dias_exactos); ?> dias
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                            LICENCIA
                                                            <br> EXPIRADA
                                                        </span>
                                                    <?php endif; ?>
                                                </h5>
                                            </td>
                                            
                                            <td>
                                                <a class="btn btn-info"
                                                    href="<?php echo e(route('operadores.edit', $operadore->id)); ?>">
                                                    <i class="fas fa-edit"></i></a>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="$('#delete<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('show')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php $__currentLoopData = $operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operadore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>Informacion de
                                <?php echo e($operadore->nombreoperador); ?></b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <b>Fecha Nacimiento:</b>
                        <li class="list-group-item">
                            <?php echo e($operadore->fechanacimiento); ?>

                        </li>
                        <br>
                        <b>Numero de Licencia:</b>
                        <li class="list-group-item">
                            <?php echo e($operadore->nolicencia); ?>

                        </li>
                        <br>
                        <b>Tipo de Licencia:</b>
                        <li class="list-group-item">
                            <?php echo e($operadore->tipolicencia); ?>

                        </li>
                        <br>
                        <b>Fecha de Vencimiento Medico:</b>
                        <li class="list-group-item">
                            <?php echo e($operadore->fechavencimientomedico); ?>

                        </li>
                        <br>
                        <b>Fecha de Vencimiento Licencia:</b>
                        <li class="list-group-item">
                            <?php echo e($operadore->fechavencimientolicencia); ?>

                        </li>
                        <br>
                        <b>cliente:</b>
                        <li class="list-group-item">
                            <?php echo e($operadore->cliente); ?>

                        </li>
                        <br>
                        <b>Licencia:</b>
                        <li class="list-group-item">
                            <object type="application/pdf" data="<?php echo e(asset($operadore->licencia)); ?>"
                                style="width: 400px; height: 300px;">
                                ERROR (no puede mostrarse el objeto)
                            </object>
                        </li>
                        <br>
                        <b>Certificación:</b>
                        <li class="list-group-item">
                            <object type="application/pdf" data="<?php echo e(asset($operadore->curso)); ?>"
                                style="width: 400px; height: 300px;">
                                ERROR (no puede mostrarse el objeto)
                            </object>
                        </li>
                        <br>
                        <b>Examen Medico:</b>
                        <li class="list-group-item">
                            <object type="application/pdf" data="<?php echo e(asset($operadore->examenmedico)); ?>"
                                style="width: 400px; height: 300px;">
                                ERROR (no puede mostrarse el objeto)
                            </object>
                        </li>
                        <br>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="delete<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>" tabindex="-1"
            role="dialog" aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar al Operador
                                <?php echo e($operadore->nombreoperador); ?>?</b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#delete<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('operadores.destroy', $operadore->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>" tabindex="-1"
            role="dialog" aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>
                                Licencia del operador
                                <?php echo e($operadore->nombreoperador); ?></b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('operadores.update', $operadore->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="cliente">cliente</label>
                                                <input type="text" name="cliente" class="form-control"
                                                    value="<?php echo e($operadore->cliente); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="nombreoperador">Nombre del Operador</label>
                                                <input type="text" name="nombreoperador" class="form-control"
                                                    value="<?php echo e($operadore->nombreoperador); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="fechanacimiento">Fecha de Nacimiento</label>
                                                <input type="date" name="fechanacimiento" class="form-control"
                                                    value="<?php echo e($operadore->fechanacimiento); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="nolicencia">No Licencia</label>
                                                <input type="text" name="nolicencia" class="form-control"
                                                    value="<?php echo e($operadore->nolicencia); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="tipolicencia">Tipo de Licencia</label>
                                                <select name="tipolicencia" id="tipolicencia" class=" selectsearch">
                                                    <option disabled selected value="">Selecciona el Tipo de Licencia
                                                    </option>
                                                    <?php if($operadore->tipolicencia == 'Federal'): ?>
                                                        <option selected value="Federal">Federal</option>
                                                    <?php else: ?>
                                                        <option value="Federal">Federal</option>
                                                    <?php endif; ?>
                                                    <?php if($operadore->tipolicencia == 'Estatal'): ?>
                                                        <option selected value="Estatal">Estatal</option>
                                                    <?php else: ?>
                                                        <option value="Estatal">Estatal</option>
                                                    <?php endif; ?>
                                                    
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="fechavencimientomedico">Fecha de Vencimiento Medico</label>
                                                <input type="date" name="fechavencimientomedico" class="form-control"
                                                    value="<?php echo e($operadore->fechavencimientomedico); ?>"
                                                    min="<?php echo e(date('Y-n-d')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="fechavencimientolicencia">Fecha de Vencimiento Licencia</label>
                                                <input type="date" name="fechavencimientolicencia"
                                                    class="form-control"
                                                    value="<?php echo e($operadore->fechavencimientolicencia); ?>"min="<?php echo e(date('Y-n-d')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="unidad">unidad</label>
                                                <input type="text" name="unidad" class="form-control"
                                                    value="<?php echo e($operadore->unidad); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="licenciaruta">licenciaruta</label>
                                                <input type="text" name="licenciaruta" class="form-control"
                                                    value="<?php echo e($operadore->licencia); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="cursoruta">cursoruta</label>
                                                <input type="text" name="cursoruta" class="form-control"
                                                    value="<?php echo e($operadore->curso); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="examenmedicoruta">examenmedicoruta</label>
                                                <input type="text" name="examenmedicoruta" class="form-control"
                                                    value="<?php echo e($operadore->examenmedico); ?>">
                                            </div>
                                        </div>
                                        <br>
                                        
                                        <div class="form">
                                            <div class="grid">
                                                
                                                <div class="form-element">
                                                    <div class="from-group">
                                                        <input name="licencia" type="file"
                                                            id="licencia_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>">
                                                        <label
                                                            for="licencia_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>"
                                                            id="licencia_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>-preview">
                                                            <object type="application/pdf"
                                                                data="<?php echo e(asset($operadore->licencia)); ?>"
                                                                style="width: 200px; height: 250px;">
                                                                ERROR (no puede mostrarse el objeto)
                                                            </object>
                                                            <div>
                                                                <span>+</span>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="form">
                                                        <label>Licencia</label>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-element"hidden>
                                                    <div class="from-group">
                                                        <input name="curso" type="file" id="curso">
                                                        <label for="curso" id="curso-preview">
                                                            <object type="application/pdf"
                                                                data="<?php echo e(asset($operadore->curso)); ?>"
                                                                style="width: 200px; height: 250px;">
                                                                ERROR (no puede mostrarse el objeto)
                                                            </object>
                                                            <div>
                                                                <span>+</span>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="from">
                                                        <label>Certificado</label>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-element"hidden>
                                                    <div class="from-group">
                                                        <input name="examenmedico" type="file" id="examenmedico">
                                                        <label for="examenmedico" id="examenmedico-preview">
                                                            <object type="application/pdf"
                                                                data="<?php echo e(asset($operadore->examenmedico)); ?>"
                                                                style="width: 200px; height: 250px;">
                                                                ERROR (no puede mostrarse el objeto)
                                                            </object>
                                                            <div>
                                                                <span>+</span>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="form">
                                                        <label>Examen Medico</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <br>
                                        </div>
                                        <br>
                                        <br>
                                        <button type="submit" class="btn btn-primary">
                                            GUARDAR</button>
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">
                                            CANCELAR</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
         
         <div class="modal fade" id="medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>" tabindex="-1"
            role="dialog" aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>
                                Medico del operador
                                <?php echo e($operadore->nombreoperador); ?></b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#medico<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('operadores.update', $operadore->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="cliente">cliente</label>
                                                <input type="text" name="cliente" class="form-control"
                                                    value="<?php echo e($operadore->cliente); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="nombreoperador">Nombre del Operador</label>
                                                <input type="text" name="nombreoperador" class="form-control"
                                                    value="<?php echo e($operadore->nombreoperador); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="fechanacimiento">Fecha de Nacimiento</label>
                                                <input type="date" name="fechanacimiento" class="form-control"
                                                    value="<?php echo e($operadore->fechanacimiento); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="nolicencia">No Licencia</label>
                                                <input type="text" name="nolicencia" class="form-control"
                                                    value="<?php echo e($operadore->nolicencia); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="tipolicencia">Tipo de Licencia</label>
                                                <select name="tipolicencia" id="tipolicencia" class=" selectsearch">
                                                    <option disabled selected value="">Selecciona el Tipo de Licencia
                                                    </option>
                                                    <?php if($operadore->tipolicencia == 'Federal'): ?>
                                                        <option selected value="Federal">Federal</option>
                                                    <?php else: ?>
                                                        <option value="Federal">Federal</option>
                                                    <?php endif; ?>
                                                    <?php if($operadore->tipolicencia == 'Estatal'): ?>
                                                        <option selected value="Estatal">Estatal</option>
                                                    <?php else: ?>
                                                        <option value="Estatal">Estatal</option>
                                                    <?php endif; ?>
                                                    
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="fechavencimientomedico">Fecha de Vencimiento Medico</label>
                                                <input type="date" name="fechavencimientomedico" class="form-control"
                                                    value="<?php echo e($operadore->fechavencimientomedico); ?>"
                                                    min="<?php echo e(date('Y-n-d')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12"hidden>
                                            <div class="form-group">
                                                <label for="fechavencimientolicencia">Fecha de Vencimiento Licencia</label>
                                                <input type="date" name="fechavencimientolicencia"
                                                    class="form-control"
                                                    value="<?php echo e($operadore->fechavencimientolicencia); ?>"min="<?php echo e(date('Y-n-d')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="unidad">unidad</label>
                                                <input type="text" name="unidad" class="form-control"
                                                    value="<?php echo e($operadore->unidad); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="licenciaruta">licenciaruta</label>
                                                <input type="text" name="licenciaruta" class="form-control"
                                                    value="<?php echo e($operadore->licencia); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="cursoruta">cursoruta</label>
                                                <input type="text" name="cursoruta" class="form-control"
                                                    value="<?php echo e($operadore->curso); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="examenmedicoruta">examenmedicoruta</label>
                                                <input type="text" name="examenmedicoruta" class="form-control"
                                                    value="<?php echo e($operadore->examenmedico); ?>">
                                            </div>
                                        </div>
                                        <br>
                                        
                                        <div class="form">
                                            <div class="grid">
                                                
                                                <div class="form-element"hidden>
                                                    <div class="from-group">
                                                        <input name="licencia" type="file"
                                                            id="licencia_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>">
                                                        <label
                                                            for="licencia_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>"
                                                            id="licencia_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>-preview">
                                                            <object type="application/pdf"
                                                                data="<?php echo e(asset($operadore->licencia)); ?>"
                                                                style="width: 200px; height: 250px;">
                                                                ERROR (no puede mostrarse el objeto)
                                                            </object>
                                                            <div>
                                                                <span>+</span>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="form">
                                                        <label>Licencia</label>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-element"hidden>
                                                    <div class="from-group">
                                                        <input name="curso" type="file" id="curso">
                                                        <label for="curso" id="curso-preview">
                                                            <object type="application/pdf"
                                                                data="<?php echo e(asset($operadore->curso)); ?>"
                                                                style="width: 200px; height: 250px;">
                                                                ERROR (no puede mostrarse el objeto)
                                                            </object>
                                                            <div>
                                                                <span>+</span>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="from">
                                                        <label>Certificado</label>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-element">
                                                    <div class="from-group">
                                                        <input name="examenmedico" type="file"
                                                        id="examenmedico_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>">
                                                        <label for="examenmedico_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>"
                                                            id="examenmedico_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>-preview">
                                                            <object type="application/pdf"
                                                                data="<?php echo e(asset($operadore->examenmedico)); ?>"
                                                                style="width: 200px; height: 250px;">
                                                                ERROR (no puede mostrarse el objeto)
                                                            </object>
                                                            <div>
                                                                <span>+</span>
                                                            </div>
                                                        </label>
                                                    </div>
                                                    <div class="form">
                                                        <label>Examen Medico</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                            <br>
                                        </div>
                                        <br>
                                        <br>
                                        <button type="submit" class="btn btn-primary">
                                            GUARDAR</button>
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#licencia<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>').modal('hide')">
                                            CANCELAR</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <script>
        //================================================ //BUG: IMAGE PREVIEW ========================================
        function previewBeforeUpload(id) {
            document.querySelector("#" + id).addEventListener("change", function(e) {
                if (e.target.files.length == 0) {
                    return;
                }
                let file = e.target.files[0];
                let url = URL.createObjectURL(file);
                document.querySelector("#" + id + "-preview div").innerText = file.name;
                document.querySelector("#" + id + "-preview object").data = url;
            });
        }
    </script>
    <?php $__currentLoopData = $operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operadore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            previewBeforeUpload("licencia_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>");
            previewBeforeUpload("examenmedico_img<?php echo e(str_replace(' ', '', $operadore->nombreoperador)); ?>");
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/operadores/index.blade.php ENDPATH**/ ?>