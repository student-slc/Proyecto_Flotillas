<?php $__env->startSection('title'); ?>
    Unidades
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Unidades de <?php echo e($usuario); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="card-body">
                    <a class="btn btn-danger" href="<?php echo e(route('clientes.index')); ?>">Regresar</a>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general-rol')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('unidades.crear', $usuario)); ?>">Nuevo</a>
                            <?php endif; ?>
                            <table id='tablas-style' class="table table-striped mt-2">
                                
                                
                                <br><br>
                                <thead style="background-color: #9dbad5">
                                    <th style="display: none;">ID</th>
                                    <?php if($mostrar == 'Placas'): ?>
                                        <th style="color:#fff;">Placas/<br>Dirección</th>
                                    <?php endif; ?>
                                    <?php if($mostrar == 'Economico'): ?>
                                        <th style="color:#fff;">Economico/<br>Dirección</th>
                                    <?php endif; ?>


                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona información detallada de la unidad">
                                            Información
                                        </div>
                                    </th>

                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona información de seguros de Responsabilidad Civil">
                                            Estado Seguro
                                        </div>
                                    </th>

                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona información de Inspección Emisiones Contaminantes">
                                            Inspección Ambiental
                                        </div>
                                    </th>

                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona información de Inspección Físico-Mecánica">
                                            Inspección Físico-Mecánica
                                        </div>
                                    </th>

                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona información del Mantenimiento Preventivo">
                                            Estado de Mantenimiento
                                        </div>
                                    </th>

                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona información fechada de la Fumigación">
                                            Estado Fumigación
                                        </div>
                                    </th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-unidades', 'borrar-unidades')): ?>
                                        <th style="color:#fff;">Acciones</th>
                                    <?php endif; ?>

                        </div>

                        </thead>
                        <tbody>
                            <?php
                                $a = 'a';
                            ?>
                            <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="display: none;"><?php echo e($unidade->id); ?></td>
                                    <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                        <?php if($mostrar == 'Placas'): ?>
                                            <td><?php echo e($unidade->direccion); ?></td>
                                        <?php endif; ?>
                                        <?php if($mostrar == 'Economico'): ?>
                                            <td><?php echo e($unidade->economico); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                        <?php if($mostrar == 'Placas'): ?>
                                            <td><?php echo e($unidade->placas); ?></td>
                                        <?php endif; ?>
                                        <?php if($mostrar == 'Economico'): ?>
                                            <td><?php echo e($unidade->economico); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    <td>
                                        <button type="button" class="btn btn-sm" style="background-color: #9dbad5"
                                            onclick="$('#<?php echo e($a); ?>').modal('show')">
                                            Detalles
                                        </button>
                                    </td>
                                    
                                    <td>
                                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial' || $unidade->status_seguro == 'No'): ?>
                                            <h6><span class="badge badge-dark">
                                                    NO APLICA
                                                </span>
                                            </h6>
                                        <?php else: ?>
                                            <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                <?php if($unidade->seguro == 'Sin Seguro'): ?>
                                                    <?php if($servicios_seguro == 'No'): ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light">Sin
                                                                    <br> Seguro</a></span>
                                                        </h6>
                                                    <?php else: ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light"
                                                                    href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Sin
                                                                    <br> Seguro</a></span>
                                                        </h6>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    
                                                    <?php
                                                        /* FECHA LICENCIA */
                                                        $vencimiento_dia = substr($unidade->seguro_fecha, 8, 2);
                                                        $vencimiento_mes = substr($unidade->seguro_fecha, 5, 2);
                                                        $vencimiento_año = substr($unidade->seguro_fecha, 0, 4);
                                                        /* FECHA ACTUAL */
                                                        $año_actual = date('Y');
                                                        $mes_actual = date('n');
                                                        $dia_actual = date('d');
                                                        /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                        $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                        /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                        $uno = 'nulo';
                                                        $calcular = 0;
                                                        $mes_contador = 1;
                                                        $dias_exactos = 1;
                                                        //cambio
                                                        if ($diferencia_año >= 1) {
                                                            $meses = $diferencia_año * 12 + 12;
                                                            $operacion_1 = $meses - (int) $mes_actual;
                                                            $operacion_2 = 12 - (int) $vencimiento_mes;
                                                            $operacion_3 = $operacion_1 - $operacion_2;
                                                            $meses = $operacion_3;
                                                        } else {
                                                            if ($diferencia_año == 0) {
                                                                $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                            } else {
                                                                $mes_contador = 0;
                                                                $dias_exactos = 0;
                                                            }
                                                        }
                                                        if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                            $uno = 'uno';
                                                            $calcular = 0;
                                                        } else {
                                                            $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                            $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                            $calcular = $direstantes + (int) $vencimiento_dia;
                                                        }
                                                        /* CALCULO DE DIAS EXACTOS */
                                                        $contador_1 = 0;
                                                        $contador_2 = 0;
                                                        $cuenta_mes = $mes_actual;
                                                        $operacion_1 = 0;
                                                        if ($mes_contador == 1 && $dias_exactos == 1) {
                                                            $mes_contador = 0;
                                                            $dias_exactos = 0;
                                                            for ($i = 0; $i <= $meses; $i++) {
                                                                if ($uno == 'uno') {
                                                                    $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                                    $i = $meses + 1;
                                                                } else {
                                                                    if ($contador_1 == 0) {
                                                                        $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                        $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                        $dias_exactos = $dias_exactos + $operacion_2;
                                                                        $contador_1 = 1;
                                                                    } else {
                                                                        if ($i == $meses) {
                                                                            $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                        } else {
                                                                            $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                            $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                            $mes_contador = $mes_contador + 1;
                                                                        }
                                                                    }
                                                                    if ($cuenta_mes == 12) {
                                                                        $contador_2 = $contador_2 + 1;
                                                                        $cuenta_mes = 1;
                                                                    } else {
                                                                        $cuenta_mes = $cuenta_mes + 1;
                                                                    }
                                                                }
                                                            }
                                                            /* CALCULO DE MESES EXACTOS */
                                                        
                                                            $dias_resto = $calcular;
                                                            $opc = 2;
                                                            for ($i = 0; $i <= $opc; $i++) {
                                                                if ($calcular >= 30) {
                                                                    $mes_contador = $mes_contador + 1;
                                                                    $calcular = $calcular - 30;
                                                                }
                                                            }
                                                        }
                                                    ?>
                                                    
                                                    
                                                    <h6>
                                                        <?php if($servicios_seguro == 'No'): ?>
                                                            <?php if($mes_contador >= 9): ?>
                                                                <span class="badge badge-primary">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <span class="badge badge-success">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <span class="badge badge-warning">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($calcular == 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                        </a> </span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                            <br>y <?php echo e($calcular); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">
                                                                        Seguro
                                                                        <br> Expirado
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($mes_contador >= 9): ?>
                                                                <span class="badge badge-primary">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <span class="badge badge-success">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <span class="badge badge-warning">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($calcular == 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                        </a> </span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                            <br>y <?php echo e($calcular); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('unidades.show', $unidad = $unidade->serieunidad)); ?>">
                                                                        Seguro
                                                                        <br> Expirado
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </h6>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial' || $unidade->status_ambiental == 'No'): ?>
                                            <h6><span class="badge badge-dark">
                                                    NO APLICA
                                                </span>
                                            </h6>
                                        <?php else: ?>
                                            <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                <?php if($unidade->verificacion == 'Sin Verificación'): ?>
                                                    <?php if($servicios_ambiental == 'No'): ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light">Sin
                                                                    <br> Verificación</a></span>
                                                        </h6>
                                                    <?php else: ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light"
                                                                    href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Sin
                                                                    <br> Verificación</a></span>
                                                        </h6>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    
                                                    <?php
                                                        /* FECHA LICENCIA */
                                                        $vencimiento_dia = substr($unidade->verificacion_fecha, 8, 2);
                                                        $vencimiento_mes = substr($unidade->verificacion_fecha, 5, 2);
                                                        $vencimiento_año = substr($unidade->verificacion_fecha, 0, 4);
                                                        /* FECHA ACTUAL */
                                                        $año_actual = date('Y');
                                                        $mes_actual = date('n');
                                                        $dia_actual = date('d');
                                                        /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                        $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                        /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                        $uno = 'nulo';
                                                        $calcular = 0;
                                                        $mes_contador = 1;
                                                        $dias_exactos = 1;
                                                        //cambio
                                                        if ($diferencia_año >= 1) {
                                                            $meses = $diferencia_año * 12 + 12;
                                                            $operacion_1 = $meses - (int) $mes_actual;
                                                            $operacion_2 = 12 - (int) $vencimiento_mes;
                                                            $operacion_3 = $operacion_1 - $operacion_2;
                                                            $meses = $operacion_3;
                                                        } else {
                                                            if ($diferencia_año == 0) {
                                                                $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                            } else {
                                                                $mes_contador = 0;
                                                                $dias_exactos = 0;
                                                            }
                                                        }
                                                        if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                            $uno = 'uno';
                                                            $calcular = 0;
                                                        } else {
                                                            $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                            $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                            $calcular = $direstantes + (int) $vencimiento_dia;
                                                        }
                                                        /* CALCULO DE DIAS EXACTOS */
                                                        $contador_1 = 0;
                                                        $contador_2 = 0;
                                                        $cuenta_mes = $mes_actual;
                                                        $operacion_1 = 0;
                                                        if ($mes_contador == 1 && $dias_exactos == 1) {
                                                            $mes_contador = 0;
                                                            $dias_exactos = 0;
                                                            for ($i = 0; $i <= $meses; $i++) {
                                                                if ($uno == 'uno') {
                                                                    $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                                    $i = $meses + 1;
                                                                } else {
                                                                    if ($contador_1 == 0) {
                                                                        $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                        $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                        $dias_exactos = $dias_exactos + $operacion_2;
                                                                        $contador_1 = 1;
                                                                    } else {
                                                                        if ($i == $meses) {
                                                                            $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                        } else {
                                                                            $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                            $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                            $mes_contador = $mes_contador + 1;
                                                                        }
                                                                    }
                                                                    if ($cuenta_mes == 12) {
                                                                        $contador_2 = $contador_2 + 1;
                                                                        $cuenta_mes = 1;
                                                                    } else {
                                                                        $cuenta_mes = $cuenta_mes + 1;
                                                                    }
                                                                }
                                                            }
                                                            /* CALCULO DE MESES EXACTOS */
                                                        
                                                            $dias_resto = $calcular;
                                                            $opc = 2;
                                                            for ($i = 0; $i <= $opc; $i++) {
                                                                if ($calcular >= 30) {
                                                                    $mes_contador = $mes_contador + 1;
                                                                    $calcular = $calcular - 30;
                                                                }
                                                            }
                                                        }
                                                    ?>
                                                    
                                                    
                                                    <h6>
                                                        <?php if($servicios_ambiental == 'No'): ?>
                                                            <?php if($mes_contador >= 9): ?>
                                                                <span class="badge badge-primary">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <span class="badge badge-success">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <span class="badge badge-warning">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($calcular == 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                        </a> </span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                            <br>y <?php echo e($calcular); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">
                                                                        Verificación
                                                                        <br> Expirada
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($mes_contador >= 9): ?>
                                                                <span class="badge badge-primary">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <span class="badge badge-success">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <span class="badge badge-warning">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($calcular == 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                        </a> </span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                            <br>y <?php echo e($calcular); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificaciones.show', $unidad = $unidade->serieunidad)); ?>">
                                                                        Verificación
                                                                        <br> Expirada
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </h6>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial' || $unidade->status_fisica == 'No'): ?>
                                            <h6><span class="badge badge-dark">
                                                    NO APLICA
                                                </span>
                                            </h6>
                                        <?php else: ?>
                                            <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                <?php if($unidade->verificacion2 == 'Sin Verificación'): ?>
                                                    <?php if($servicios_fisica == 'No'): ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light">Sin
                                                                    <br>Verificación</a></span>
                                                        </h6>
                                                    <?php else: ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light"
                                                                    href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Sin
                                                                    <br>Verificación</a></span>
                                                        </h6>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    
                                                    <?php
                                                        /* FECHA LICENCIA */
                                                        $vencimiento_dia = substr($unidade->verificacion_fecha2, 8, 2);
                                                        $vencimiento_mes = substr($unidade->verificacion_fecha2, 5, 2);
                                                        $vencimiento_año = substr($unidade->verificacion_fecha2, 0, 4);
                                                        /* FECHA ACTUAL */
                                                        $año_actual = date('Y');
                                                        $mes_actual = date('n');
                                                        $dia_actual = date('d');
                                                        /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                        $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                        /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                        $uno = 'nulo';
                                                        $calcular = 0;
                                                        $mes_contador = 1;
                                                        $dias_exactos = 1;
                                                        //cambio
                                                        if ($diferencia_año >= 1) {
                                                            $meses = $diferencia_año * 12 + 12;
                                                            $operacion_1 = $meses - (int) $mes_actual;
                                                            $operacion_2 = 12 - (int) $vencimiento_mes;
                                                            $operacion_3 = $operacion_1 - $operacion_2;
                                                            $meses = $operacion_3;
                                                        } else {
                                                            if ($diferencia_año == 0) {
                                                                $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                            } else {
                                                                $mes_contador = 0;
                                                                $dias_exactos = 0;
                                                            }
                                                        }
                                                        if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                            $uno = 'uno';
                                                            $calcular = 0;
                                                        } else {
                                                            $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                            $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                            $calcular = $direstantes + (int) $vencimiento_dia;
                                                        }
                                                        /* CALCULO DE DIAS EXACTOS */
                                                        $contador_1 = 0;
                                                        $contador_2 = 0;
                                                        $cuenta_mes = $mes_actual;
                                                        $operacion_1 = 0;
                                                        if ($mes_contador == 1 && $dias_exactos == 1) {
                                                            $mes_contador = 0;
                                                            $dias_exactos = 0;
                                                            for ($i = 0; $i <= $meses; $i++) {
                                                                if ($uno == 'uno') {
                                                                    $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                                    $i = $meses + 1;
                                                                } else {
                                                                    if ($contador_1 == 0) {
                                                                        $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                        $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                        $dias_exactos = $dias_exactos + $operacion_2;
                                                                        $contador_1 = 1;
                                                                    } else {
                                                                        if ($i == $meses) {
                                                                            $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                        } else {
                                                                            $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                            $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                            $mes_contador = $mes_contador + 1;
                                                                        }
                                                                    }
                                                                    if ($cuenta_mes == 12) {
                                                                        $contador_2 = $contador_2 + 1;
                                                                        $cuenta_mes = 1;
                                                                    } else {
                                                                        $cuenta_mes = $cuenta_mes + 1;
                                                                    }
                                                                }
                                                            }
                                                            /* CALCULO DE MESES EXACTOS */
                                                        
                                                            $dias_resto = $calcular;
                                                            $opc = 2;
                                                            for ($i = 0; $i <= $opc; $i++) {
                                                                if ($calcular >= 30) {
                                                                    $mes_contador = $mes_contador + 1;
                                                                    $calcular = $calcular - 30;
                                                                }
                                                            }
                                                        }
                                                    ?>
                                                    
                                                    
                                                    <h6>
                                                        <?php if($servicios_fisica == 'No'): ?>
                                                            <?php if($mes_contador >= 9): ?>
                                                                <span class="badge badge-primary">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <span class="badge badge-success">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <span class="badge badge-warning">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($calcular == 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                        </a> </span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                            <br>y <?php echo e($calcular); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light">
                                                                        Verificación
                                                                        <br> Expirada
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($mes_contador >= 9): ?>
                                                                <span class="badge badge-primary">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <span class="badge badge-success">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <span class="badge badge-warning">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($mes_contador); ?> meses</a>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($calcular == 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                        </a> </span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en:<br>
                                                                            <?php echo e($mes_contador); ?> mes
                                                                            <br>y <?php echo e($calcular); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                        en:<br>
                                                                        <?php echo e($dias_exactos); ?> dias
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <span class="badge badge-danger">
                                                                    <a class="link-light"
                                                                        href="<?php echo e(route('verificacionesfisicomecanicas.show', $unidad = $unidade->serieunidad)); ?>">
                                                                        Verificación
                                                                        <br> Expirada
                                                                    </a> </span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </h6>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial' || $unidade->status_mantenimiento == 'No'): ?>
                                            <h6><span class="badge badge-dark">
                                                    NO APLICA
                                                </span>
                                            </h6>
                                        <?php else: ?>
                                            <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                <?php if($unidade->mantenimiento == 'Sin Mantenimiento'): ?>
                                                    <?php if($servicios_mantenimiento == 'No'): ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light">Sin
                                                                    <br> Mantenimiento</a></span>
                                                        </h6>
                                                    <?php else: ?>
                                                        <h6><span class="badge badge-danger"><a class="link-light"
                                                                    href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Sin
                                                                    <br> Mantenimiento</a></span>
                                                        </h6>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($unidade->tipomantenimiento == 'Fecha'): ?>
                                                        
                                                        <?php
                                                            /* FECHA LICENCIA */
                                                            $vencimiento_dia = substr($unidade->mantenimiento_fecha, 8, 2);
                                                            $vencimiento_mes = substr($unidade->mantenimiento_fecha, 5, 2);
                                                            $vencimiento_año = substr($unidade->mantenimiento_fecha, 0, 4);
                                                            $vencimiento_mes = $vencimiento_mes + $unidade->frecuencia_mante;
                                                            if ($vencimiento_mes > 12) {
                                                                $vencimiento_año = $vencimiento_año + 1;
                                                                $vencimiento_mes = $vencimiento_mes - 12;
                                                            }
                                                            /* FECHA ACTUAL */
                                                            $año_actual = date('Y');
                                                            $mes_actual = date('n');
                                                            $dia_actual = date('d');
                                                            /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                            $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                            /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                            $uno = 'nulo';
                                                            $calcular = 0;
                                                            $mes_contador = 1;
                                                            $dias_exactos = 1;
                                                            //cambio
                                                            if ($diferencia_año >= 1) {
                                                                $meses = $diferencia_año * 12 + 12;
                                                                $operacion_1 = $meses - (int) $mes_actual;
                                                                $operacion_2 = 12 - (int) $vencimiento_mes;
                                                                $operacion_3 = $operacion_1 - $operacion_2;
                                                                $meses = $operacion_3;
                                                            } else {
                                                                if ($diferencia_año == 0) {
                                                                    $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                                } else {
                                                                    $mes_contador = 0;
                                                                    $dias_exactos = 0;
                                                                }
                                                            }
                                                            if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                                $uno = 'uno';
                                                                $calcular = 0;
                                                            } else {
                                                                $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                                $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                                $calcular = $direstantes + (int) $vencimiento_dia;
                                                            }
                                                            /* CALCULO DE DIAS EXACTOS */
                                                            $contador_1 = 0;
                                                            $contador_2 = 0;
                                                            $cuenta_mes = $mes_actual;
                                                            $operacion_1 = 0;
                                                            if ($mes_contador == 1 && $dias_exactos == 1) {
                                                                $mes_contador = 0;
                                                                $dias_exactos = 0;
                                                                for ($i = 0; $i <= $meses; $i++) {
                                                                    if ($uno == 'uno') {
                                                                        $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                                        $i = $meses + 1;
                                                                    } else {
                                                                        if ($contador_1 == 0) {
                                                                            $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                            $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                            $dias_exactos = $dias_exactos + $operacion_2;
                                                                            $contador_1 = 1;
                                                                        } else {
                                                                            if ($i == $meses) {
                                                                                $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                            } else {
                                                                                $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                                $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                                $mes_contador = $mes_contador + 1;
                                                                            }
                                                                        }
                                                                        if ($cuenta_mes == 12) {
                                                                            $contador_2 = $contador_2 + 1;
                                                                            $cuenta_mes = 1;
                                                                        } else {
                                                                            $cuenta_mes = $cuenta_mes + 1;
                                                                        }
                                                                    }
                                                                }
                                                                /* CALCULO DE MESES EXACTOS */
                                                            
                                                                $dias_resto = $calcular;
                                                                $opc = 2;
                                                                for ($i = 0; $i <= $opc; $i++) {
                                                                    if ($calcular >= 30) {
                                                                        $mes_contador = $mes_contador + 1;
                                                                        $calcular = $calcular - 30;
                                                                    }
                                                                }
                                                            }
                                                        ?>
                                                        
                                                        
                                                        <h6>
                                                            <?php if($servicios_mantenimiento == 'No'): ?>
                                                                <?php if($mes_contador >= 9): ?>
                                                                    <span class="badge badge-primary">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                    <span class="badge badge-success">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                    <span class="badge badge-warning">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                    <?php if($calcular == 0): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes
                                                                            </a> </span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes <br> y
                                                                                <?php echo e($calcular); ?> dias
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">
                                                                            Mantenimiento
                                                                            <br> Expirado
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($mes_contador >= 9): ?>
                                                                    <span class="badge badge-primary">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                    <span class="badge badge-success">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                    <span class="badge badge-warning">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                    <?php if($calcular == 0): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes
                                                                            </a> </span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes <br> y
                                                                                <?php echo e($calcular); ?> dias
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">
                                                                            Mantenimiento
                                                                            <br> Expirado
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </h6>
                                                    <?php endif; ?>
                                                    
                                                    
                                                    <h6>
                                                        <?php if($unidade->tipomantenimiento == 'Kilometraje'): ?>
                                                            <?php
                                                                $km_contador = $unidade->kilometros_contador;
                                                                $frecuencia = $unidade->frecuencia_mante;
                                                                $km_actual = $unidade->kilometros_actuales;
                                                                $diferencia = $frecuencia + $km_actual - $km_contador;
                                                            ?>
                                                            <?php if($servicios_mantenimiento == 'No'): ?>
                                                                <?php if($km_contador >= $frecuencia + $km_actual): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">
                                                                            Mantenimiento
                                                                            <br> Expirado
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($km_contador < $frecuencia + $km_actual): ?>
                                                                    <?php
                                                                        $diferencia = $frecuencia + $km_actual - $km_contador;
                                                                    ?>
                                                                    <?php if($diferencia >= 1 && $diferencia < 100): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                    <?php if($diferencia >= 100 && $diferencia < 300): ?>
                                                                        <span class="badge badge-warning">
                                                                            <a class="link-light">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                    <?php if($diferencia >= 300 && $diferencia < 500): ?>
                                                                        <span class="badge badge-success">
                                                                            <a class="link-light">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                    <?php if($diferencia >= 500): ?>
                                                                        <span class="badge badge-primary">
                                                                            <a class="link-light">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <?php if($km_contador >= $frecuencia + $km_actual): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">
                                                                            Mantenimiento
                                                                            <br> Expirado
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($km_contador < $frecuencia + $km_actual): ?>
                                                                    <?php
                                                                        $diferencia = $frecuencia + $km_actual - $km_contador;
                                                                    ?>
                                                                    <?php if($diferencia >= 1 && $diferencia < 100): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                    <?php if($diferencia >= 100 && $diferencia < 300): ?>
                                                                        <span class="badge badge-warning">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                    <?php if($diferencia >= 300 && $diferencia < 500): ?>
                                                                        <span class="badge badge-success">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                    <?php if($diferencia >= 500): ?>
                                                                        <span class="badge badge-primary">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('mantenimientos.show', $unidad = $unidade->serieunidad)); ?>">
                                                                                <?php echo e($diferencia); ?> Km
                                                                                <br> Para expirar
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </h6>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if($unidade->lapsofumigacion != 'Reprogramado' && $unidade->lapsofumigacion != 'Pendiente'): ?>
                                            <?php if($unidade->tipo == 'Unidad Vehicular' && $unidade->status_fumigacion == 'No'): ?>
                                                <h6><span class="badge badge-dark">
                                                        NO APLICA
                                                    </span>
                                                </h6>
                                            <?php else: ?>
                                                <?php if($unidade->fumigacion == 'Sin Fumigación'): ?>
                                                    <?php if($servicios_fumigacion == 'No'): ?>
                                                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                            <h6><span class="badge badge-danger"><a class="link-light">Sin
                                                                        <br>Fumigación</a></span>
                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                            <h6><span class="badge badge-danger"><a class="link-light">Sin
                                                                        <br>Fumigación</a></span>
                                                            </h6>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                            <h6><span class="badge badge-danger"><a class="link-light"
                                                                        href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Sin
                                                                        <br>Fumigación</a></span>
                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                            <h6><span class="badge badge-danger"><a class="link-light"
                                                                        href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Sin
                                                                        <br>Fumigación</a></span>
                                                            </h6>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    
                                                    <?php
                                                        /* FECHA LICENCIA */
                                                        $vencimiento_dia = substr($unidade->lapsofumigacion, 8, 2);
                                                        $vencimiento_mes = substr($unidade->lapsofumigacion, 5, 2);
                                                        $vencimiento_año = substr($unidade->lapsofumigacion, 0, 4);
                                                        $vencimiento_mes = $vencimiento_mes + $unidade->frecuencia_fumiga;
                                                        if ($vencimiento_mes > 12) {
                                                            $vencimiento_año = $vencimiento_año + 1;
                                                            $vencimiento_mes = $vencimiento_mes - 12;
                                                        }
                                                        /* FECHA ACTUAL */
                                                        $año_actual = date('Y');
                                                        $mes_actual = date('n');
                                                        $dia_actual = date('d');
                                                        /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                        $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                        /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                        $uno = 'nulo';
                                                        $calcular = 0;
                                                        $mes_contador = 1;
                                                        $dias_exactos = 1;
                                                        //cambio
                                                        if ($diferencia_año >= 1) {
                                                            $meses = $diferencia_año * 12 + 12;
                                                            $operacion_1 = $meses - (int) $mes_actual;
                                                            $operacion_2 = 12 - (int) $vencimiento_mes;
                                                            $operacion_3 = $operacion_1 - $operacion_2;
                                                            $meses = $operacion_3;
                                                        } else {
                                                            if ($diferencia_año == 0) {
                                                                $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                            } else {
                                                                $mes_contador = 0;
                                                                $dias_exactos = 0;
                                                            }
                                                        }
                                                        if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                            $uno = 'uno';
                                                            $calcular = 0;
                                                        } else {
                                                            $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                            $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                            $calcular = $direstantes + (int) $vencimiento_dia;
                                                        }
                                                        /* CALCULO DE DIAS EXACTOS */
                                                        $contador_1 = 0;
                                                        $contador_2 = 0;
                                                        $cuenta_mes = $mes_actual;
                                                        $operacion_1 = 0;
                                                        if ($mes_contador == 1 && $dias_exactos == 1) {
                                                            $mes_contador = 0;
                                                            $dias_exactos = 0;
                                                            for ($i = 0; $i <= $meses; $i++) {
                                                                if ($uno == 'uno') {
                                                                    $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                                    $i = $meses + 1;
                                                                } else {
                                                                    if ($contador_1 == 0) {
                                                                        $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                        $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                        $dias_exactos = $dias_exactos + $operacion_2;
                                                                        $contador_1 = 1;
                                                                    } else {
                                                                        if ($i == $meses) {
                                                                            $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                        } else {
                                                                            $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                            $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                            $mes_contador = $mes_contador + 1;
                                                                        }
                                                                    }
                                                                    if ($cuenta_mes == 12) {
                                                                        $contador_2 = $contador_2 + 1;
                                                                        $cuenta_mes = 1;
                                                                    } else {
                                                                        $cuenta_mes = $cuenta_mes + 1;
                                                                    }
                                                                }
                                                            }
                                                            /* CALCULO DE MESES EXACTOS */
                                                        
                                                            $dias_resto = $calcular;
                                                            $opc = 2;
                                                            for ($i = 0; $i <= $opc; $i++) {
                                                                if ($calcular >= 30) {
                                                                    $mes_contador = $mes_contador + 1;
                                                                    $calcular = $calcular - 30;
                                                                }
                                                            }
                                                        }
                                                    ?>
                                                    
                                                    
                                                    <h6>
                                                        <?php if($servicios_fumigacion == 'No'): ?>
                                                            <?php if($mes_contador >= 9): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-primary">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-primary">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-success">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-success">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-warning">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-warning">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <?php if($calcular == 0): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes
                                                                            </a> </span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes <br>
                                                                                <br> y <?php echo e($calcular); ?> dias
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <?php if($calcular == 0): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes
                                                                            </a> </span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes <br>
                                                                                <br> y <?php echo e($calcular); ?> dias
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">
                                                                            Fumigación
                                                                            <br> Expirada
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light">
                                                                            Fumigación
                                                                            <br> Expirada
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            
                                                            <?php if($mes_contador >= 9): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-primary">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-primary">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-success">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-success">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-warning">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-warning">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($mes_contador); ?> meses</a>
                                                                    </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <?php if($calcular == 0): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes
                                                                            </a> </span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes <br>
                                                                                <br> y <?php echo e($calcular); ?> dias
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <?php if($calcular == 0): ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes
                                                                            </a> </span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">
                                                                            <a class="link-light"
                                                                                href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                                en: <br>
                                                                                <?php echo e($mes_contador); ?> mes <br>
                                                                                <br> y <?php echo e($calcular); ?> dias
                                                                            </a> </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Expira
                                                                            en: <br>
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">
                                                                            Fumigación
                                                                            <br> Expirada
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                    <span class="badge badge-danger">
                                                                        <a class="link-light"
                                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">
                                                                            Fumigación
                                                                            <br> Expirada
                                                                        </a> </span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </h6>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if($unidade->lapsofumigacion == 'Pendiente'): ?>
                                            <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                <h6><span class="badge badge-warning"><a class="link-light"
                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Fumigación
                                                            <br>Pendiente</a></span>
                                                </h6>
                                            <?php endif; ?>
                                            <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                <h6><span class="badge badge-warning"><a class="link-light"
                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Fumigación
                                                            <br>Pendiente</a></span>
                                                </h6>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if($unidade->lapsofumigacion == 'Reprogramado'): ?>
                                            <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                <h6><span class="badge badge-warning"><a class="link-light"
                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->direccion)); ?>">Fumigación
                                                            <br>Reprogramado</a></span>
                                                </h6>
                                            <?php endif; ?>
                                            <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                <h6><span class="badge badge-warning"><a class="link-light"
                                                            href="<?php echo e(route('fumigaciones.show', $unidad = $unidade->serieunidad)); ?>">Fumigación
                                                            <br>Reprogramado</a></span>
                                                </h6>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-unidades', 'borrar-unidades')): ?>
                                        <td>
                                            <a class="btn btn-sm" style="background-color: #9dbad5"
                                                href="<?php echo e(route('unidades.edit', $unidade->id)); ?>">
                                                <i class="fas fa-pencil-alt"></i></a>

                                            <button type="submit" class="btn btn-sm" class="btn btn-sm"
                                                style="background-color: #ff8097"
                                                onclick="$('#delete<?php echo e($a); ?>').modal('show')">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>

                                        </td>
                                    <?php endif; ?>
                                </tr>
                                <?php
                                    $a = $a . 'a';
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                        <!-- Ubicamos la paginacion a la derecha -->
                        
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    
    <?php
        $a = 'a';
    ?>
    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>Informacion de
                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                    <?php echo e($unidade->direccion); ?>

                                <?php endif; ?>
                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                    <?php echo e($unidade->placas); ?>

                                <?php endif; ?>
                            </b></h5>
                        <button type="button" class="btn-close" onclick="$('#<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                            <b>Cliente:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cliente); ?>

                            </li>
                            <br>
                            <b>No. Economico:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->economico); ?>

                            </li>
                            <br>
                            <b>Digito Placa:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->digitoplaca); ?>

                            </li>
                            <br>
                            <b>Marca:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->marca); ?>

                            </li>
                            <br>
                            <b>SubMarca:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->submarca); ?>

                            </li>
                            <br>
                            <b>Año de la Unidad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->añounidad); ?>

                            </li>
                            <br>
                            <b>Kilometraje:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->kilometros_contador); ?>

                            </li>
                            <br>
                            <b>Tipo de Unidad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->tipounidad); ?>

                            </li>
                            <br>
                            <b>Razon Social:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->razonsocialunidad); ?>

                            </li>
                            <br>
                            <b>Serie de la unidad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->serieunidad); ?>

                            </li>
                            <br>
                            <b>Vencimiento Seguro:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->seguro_fecha); ?>

                            </li>
                            <br>
                            <b>Vencimiento Verificación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->verificacion_fecha); ?>

                            </li>
                            <br>
                            <?php if($unidade->tipomantenimiento == 'Fecha'): ?>
                                <b>Tipo de Mantenimiento:</b>
                                <li class="list-group-item">
                                    Mantenimiento por Fecha de Vencimiento
                                </li>
                                <br>
                            <?php endif; ?>
                            <?php if($unidade->tipomantenimiento == 'Kilometraje'): ?>
                                <b>Tipo de Mantenimiento:</b>
                                <li class="list-group-item">
                                    Mantenimiento por Kilometraje
                                </li>
                                <br>
                            <?php endif; ?>
                            <b>Vencimiento Fumigación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->lapsofumigacion); ?>

                            </li>
                            <br>
                            <?php if($rol == 'Administrador' || $rol == 'SuperAdministrador'): ?>
                                <b>Comisión Fumigación:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->comisionfumigacion); ?>%
                                </li>
                                <br>
                                <b>Distancia Fumigación:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->distanciakm); ?> km
                                </li>
                                <br>
                                <b>Ltrs Gasolina:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->ltrsgasolina); ?> Ltrs
                                </li>
                                <br>
                                <b>Status:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->status); ?>

                                </li>
                                <br>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                            <b>Cliente:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cliente); ?>

                            </li>
                            <br>
                            <b>Codigo Postal:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cp); ?>

                            </li>
                            <br>
                            <b>No. Economico:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->economico); ?>

                            </li>
                            <br>
                            <b>Dirección:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->direccion); ?>

                            </li>
                            <br>
                            <b>Calle:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->calle); ?>

                            </li>
                            <br>
                            <b>Ciudad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->ciudad); ?>

                            </li>
                            <br>
                            <b>Responsable:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->responsable); ?>

                            </li>
                            <br>
                            <b>Razon Social:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->razonsocialunidad); ?>

                            </li>
                            <br>
                            <b>Vencimiento Fumigación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->lapsofumigacion); ?>

                            </li>
                            <br>
                            <?php if($rol == 'Administrador' || $rol == 'SuperAdministrador'): ?>
                                <b>Comisión Fumigación:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->comisionfumigacion); ?>%
                                </li>
                                <br>
                                <b>Distancia Fumigación:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->distanciakm); ?> km
                                </li>
                                <br>
                                <b>Ltrs Gasolina:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->ltrsgasolina); ?> Ltrs
                                </li>
                                <br>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e($a); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="delete<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar la
                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                    Vivienda <?php echo e($unidade->direccion); ?>

                                <?php endif; ?>
                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                    Unidad <?php echo e($unidade->serieunidad); ?>

                                <?php endif; ?>
                                ?
                            </b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('unidades.destroy', $unidade->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            $a = $a . 'a';
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/unidades/index.blade.php ENDPATH**/ ?>