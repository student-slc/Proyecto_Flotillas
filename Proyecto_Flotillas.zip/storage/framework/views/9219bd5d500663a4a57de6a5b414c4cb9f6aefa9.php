<?php $__env->startSection('title'); ?>
    Mantenimientos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Mantenimientos para: <?php echo e($unidad); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-danger" href="<?php echo e(route('mantenimientos.show', $unidad)); ?>">Regresar</a>
                        </div>
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-danger"><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <?php
                                /* FECHA ACTUAL */
                                $fecha_actual = date('Y-n-d');
                            ?>
                            <form action="<?php echo e(route('mantenimientos.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    
                                    <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                        <div class="form-group">
                                            <label for="id_unidad">id_unidad</label>
                                            <input type="text" name="id_unidad" class="form-control"
                                                value="<?php echo e($unidad); ?>">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                        <div class="form-group">
                                            <label for="estado">estado</label>
                                            <input type="text" name="estado" class="form-control" value="Activo">
                                        </div>
                                    </div>
                                    
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="nomantenimiento">Numero de Mantenimiento</label>
                                            <input type="text" name="nomantenimiento" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="kminiciales">Kilometros Iniciales</label>
                                            <input id="kminiciales" type="text" name="kminiciales" class="form-control"
                                            onkeyup="calcular(this)">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="kmfinales">Kilometros Finales</label>
                                            <input id="kmfinales" type="text" name="kmfinales" class="form-control"
                                            onkeyup="calcular(this)">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="kmfaltantes">Kilometros Faltantes</label>
                                            <input id="kmfaltantes"type="text" name="kmfaltantes" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="fecha">Fecha</label>
                                            <input type="date" name="fecha" class="form-control"
                                                min="<?php echo e($fecha_actual); ?>">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="frecuencia">Frecuencia</label>
                                            <input type="text" name="frecuencia" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="sigservicio">Siguiente Servicio</label>
                                            <input type="text" name="sigservicio" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="tipomantenimiento">Tipo De Mantenimiento</label>
                                            <select name="tipomantenimiento" id="tipomantenimiento" class=" selectsearch">
                                                <option disabled selected value="">Selecciona Tipo de Mantenimiento</option>
                                                <option value="Kilometraje">Mantenimiento por Kilometraje</option>
                                                <option value="Fecha">Mantenimiento por Fecha de Vencimiento</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        function calcular(input) {
            var kmfinales=document.getElementById("kmfinales").value
            var kminiciales=document.getElementById("kminiciales").value
            document.getElementById("kmfaltantes").value = kmfinales-kminiciales;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/mantenimientos/crear.blade.php ENDPATH**/ ?>