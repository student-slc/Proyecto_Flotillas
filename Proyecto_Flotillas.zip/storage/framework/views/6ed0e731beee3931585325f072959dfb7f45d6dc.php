
<?php $__env->startSection('title'); ?>
    Fumigaciones
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Fumigaciones de <?php echo e($unidad); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="card-body">
                    <a class="btn btn-danger" href="<?php echo e(route('clientes.show', $usuario = $unidad)); ?>">Regresar</a>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-warning" href="<?php echo e(route('fumigaciones.crear', $unidad)); ?>">Nuevo</a>
                            <table id='tablas-style' class="table table-striped mt-2">
                                
                                
                                <br><br>
                                <thead style="background-color: #9dbad5">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Folio Fumigación</th>
                                    <th style="color:#fff;">Información</th>
                                    <th style="color:#fff;">Status</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php
                                        $a = 'a';
                                    ?>
                                    <?php $__currentLoopData = $fumigaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fumigacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($fumigacione->id); ?></td>
                                            <td><?php echo e($fumigacione->numerofumigacion); ?></td>
                                            
                                            <td>
                                                <button type="button" class="btn btn-md" style="background-color: #9dbad5"
                                                    onclick="$('#<?php echo e($a); ?>').modal('show')">
                                                    Detalles
                                                </button>
                                            </td>
                                            
                                            <td>
                                                <?php if($fumigacione->status == 'Inactivo'): ?>
                                                    <h5>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#update<?php echo e($a); ?>').modal('show')">
                                                            Inactivo
                                                        </span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($fumigacione->status == 'Cancelado'): ?>
                                                    <h5>
                                                        <span class="badge badge-danger"
                                                            onclick="$('#update<?php echo e($a); ?>').modal('show')">
                                                            <?php echo e($fumigacione->status); ?>

                                                        </span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($fumigacione->status == 'Realizado'): ?>
                                                    <h5>
                                                        <span class="badge badge-success"
                                                            onclick="$('#update<?php echo e($a); ?>').modal('show')">
                                                            Activo
                                                        </span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($fumigacione->status == 'Reprogramado'): ?>
                                                    <h5>
                                                        <span class="badge badge-warning"
                                                            onclick="$('#update<?php echo e($a); ?>').modal('show')">
                                                            <?php echo e($fumigacione->status); ?>

                                                        </span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($fumigacione->status == 'Pendiente'): ?>
                                                    <h5>
                                                        <span class="badge badge-warning"
                                                            onclick="$('#update<?php echo e($a); ?>').modal('show')">
                                                            <?php echo e($fumigacione->status); ?>

                                                        </span>
                                                    </h5>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-sm btn-danger" href="<?php echo e(route('pdf.constancia_fumigacion', $fumigacione->id)); ?>">
                                                    <i class="fas fa-file-pdf"></i>
                                                </a>
                                                <a class="btn btn-sm" style="background-color: #9dbad5"
                                                    href="<?php echo e(route('fumigaciones.edit', $fumigacione->id)); ?>">
                                                    <i class="fas fa-pencil-alt"></i></a>
                                                <button type="submit" class="btn btn-sm" style="background-color: #ff8097"
                                                    onclick="$('#delete<?php echo e($a); ?>').modal('show')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php
                                            $a = $a . 'a';
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php
        $a = 'a';
    ?>
    <?php $__currentLoopData = $fumigaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fumigacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e($a); ?>" tabindex="-1" role="dialog" aria-labelledby="ModalDetallesTitle"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>
                                Información del Folio de Fumigación: <?php echo e($fumigacione->numerofumigacion); ?></b></h5>
                        <button type="button" class="btn-close" onclick="$('#<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <b>Unidad:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->unidad); ?>

                        </li>
                        <br>
                        <b>Fumigador:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->id_fumigador); ?>

                        </li>
                        <br>
                        <b>Fecha De Fumigación:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->fechaprogramada); ?>

                        </li>
                        <br>
                        <b>Fecha de la Ultima Fumigaciòn:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->fechaultimafumigacion); ?>

                        </li>
                        <br>
                        <b>Lugar del Servicio:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->lugardelservicio); ?>

                        </li>
                        <br>
                        <b>Numero de Visitas:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->numerodevisitas); ?>

                        </li>
                        <br>
                        <b>Costo:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->costo); ?>

                        </li>
                        <br>
                        <b>Producto Utilizado:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->producto); ?>

                        </li>
                        <br>
                        <b>Tipo:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->tipo); ?>

                        </li>
                        <br>
                        <b>Bichos Fumigados:</b>
                        <div class="card-deck">
                            <div class="card">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->insectosvoladores == 'Si'): ?> checked <?php endif; ?> id="insectosvoladores"
                                        name="insectosvoladores">
                                    <label class="form-check-label" for="insectosvoladores">
                                        Insectos Voladores
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->insectosrastreros == 'Si'): ?> checked <?php endif; ?> id="insectosrastreros"
                                        name="insectosrastreros">
                                    <label class="form-check-label" for="insectosrastreros">
                                        Insectos Rastreros
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->cucaracha == 'Si'): ?> checked <?php endif; ?> id="cucaracha" name="cucaracha">
                                    <label class="form-check-label" for="cucaracha">
                                        Cucaracha (Ger/Ori/Ame)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->pulgas == 'Si'): ?> checked <?php endif; ?> id="pulgas" name="pulgas">
                                    <label class="form-check-label" for="pulgas">
                                        Pulgas
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->mosca == 'Si'): ?> checked <?php endif; ?> id="mosca" name="mosca">
                                    <label class="form-check-label" for="mosca">
                                        Mosca
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->chinches == 'Si'): ?> checked <?php endif; ?> id="chinches" name="chinches">
                                    <label class="form-check-label" for="chinches">
                                        Chinches
                                    </label>
                                </div>
                            </div>
                            <div class="card">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->aracnidos == 'Si'): ?> checked <?php endif; ?> id="aracnidos" name="aracnidos">
                                    <label class="form-check-label" for="aracnidos">
                                        Aracnidos
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->hormigas == 'Si'): ?> checked <?php endif; ?> id="hormigas"name="hormigas">
                                    <label class="form-check-label" for="hormigas">
                                        Hormigas
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->termitas == 'Si'): ?> checked <?php endif; ?> id="termitas" name="termitas">
                                    <label class="form-check-label" for="termitas">
                                        Termitas
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->roedores == 'Si'): ?> checked <?php endif; ?> id="roedores" name="roedores">
                                    <label class="form-check-label" for="roedores">
                                        Roedores
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->alacranes == 'Si'): ?> checked <?php endif; ?> id="alacranes"
                                        name="alacranes">
                                    <label class="form-check-label" for="alacranes">
                                        Alacranes
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" disabled
                                        <?php if($fumigacione->carcamo == 'Si'): ?> checked <?php endif; ?> id="carcamo" name="carcamo">
                                    <label class="form-check-label" for="carcamo">
                                        Carcamo
                                    </label>
                                </div>
                            </div>
                        </div>
                        <br>
                        <b>Observaciones:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->observaciones); ?>

                        </li>
                        <br>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e($a); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="delete<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar la Fumigación
                                <?php echo e($fumigacione->numerofumigacion); ?>?</b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('fumigaciones.destroy', $fumigacione->id)); ?>"method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="update<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>Actualizar Status
                                Folio Fumigación:
                                <?php echo e($fumigacione->numerofumigacion); ?></b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#update<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('fumigaciones.update', $fumigacione->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="numerofumigacion">Folio de Fumigación</label>
                                                <input type="text" name="numerofumigacion" class="form-control"
                                                    value="<?php echo e($fumigacione->numerofumigacion); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="unidad">Unidad</label>
                                                <input type="text" name="unidad" class="form-control"
                                                    value="<?php echo e($fumigacione->unidad); ?>" readonly="readonly">
                                            </div>
                                        </div>
                                        
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="id_fumigador">Fumigador</label>
                                                <select name="id_fumigador" id="id_fumigador" class=" selectsearch">
                                                    <option value="<?php echo e($fumigacione->id_fumigador); ?>" selected>
                                                        <?php echo e($fumigacione->id_fumigador); ?></option>
                                                </select>
                                            </div>
                                        </div>
                                        <?php
                                            /* FECHA ACTUAL */
                                            $fecha_actual = date('Y-n-d');
                                        ?>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="fechaprogramada">Fecha de Servicio</label>
                                                <input type="datetime-local" name="fechaprogramada" class="form-control"
                                                    value="<?php echo e($fumigacione->fechaprogramada); ?>"
                                                    min="<?php echo e(date('Y-n-d')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="fechaultimafumigacion">Fecha ultima fumigacion</label>
                                                <input type="text" name="fechaultimafumigacion" class="form-control"
                                                    value="<?php echo e($fumigacione->fechaultimafumigacion); ?>"
                                                    readonly="readonly">
                                            </div>
                                        </div>
                                        
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="lugardelservicio">Lugar de Servicio</label>
                                                <input type="text" name="lugardelservicio" class="form-control"
                                                    readonly="readonly" value="<?php echo e($fumigacione->lugardelservicio); ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="tipo">Tipo</label>
                                                <select name="tipo" id="tipo" class=" selectsearch">
                                                    <option value="Tipo" selected>Tipos</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="numerodevisitas">Numero de Visitas</label>
                                                <input type="text" name="numerodevisitas" class="form-control"
                                                    value="<?php echo e($fumigacione->numerodevisitas); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="costo">Costo</label>
                                                <input type="text" name="costo" class="form-control"
                                                    value="<?php echo e($fumigacione->costo); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="producto">Producto Utilizado</label>
                                                <select name="producto" id="producto" class=" selectsearch">
                                                    <option value="CYNOFF 40 PH"
                                                        <?php if($fumigacione->producto == 'CYNOFF 40 PH'): ?> selected <?php endif; ?>>CYNOFF 40 PH
                                                    </option>
                                                    <option value="BIOTRINE FLOW"
                                                        <?php if($fumigacione->producto == 'BIOTRINE FLOW'): ?> selected <?php endif; ?>>BIOTRINE FLOW
                                                    </option>
                                                    <option value="BIOTRINE C.E."
                                                        <?php if($fumigacione->producto == 'BIOTRINE C.E.'): ?> selected <?php endif; ?>>BIOTRINE C.E.
                                                    </option>
                                                    <option value="ELEGY"
                                                        <?php if($fumigacione->producto == 'ELEGY'): ?> selected <?php endif; ?>>
                                                        ELEGY</option>
                                                    <option value="TERMIDOR"
                                                        <?php if($fumigacione->producto == 'TERMIDOR'): ?> selected <?php endif; ?>>
                                                        TERMIDOR</option>
                                                    <option value="TEMRPID SC"
                                                        <?php if($fumigacione->producto == 'TEMRPID SC'): ?> selected <?php endif; ?>>TEMRPID SC
                                                    </option>
                                                    <option value="TYSON2E"
                                                        <?php if($fumigacione->producto == 'TYSON2E'): ?> selected <?php endif; ?>>
                                                        TYSON2E</option>
                                                    <option value="DDVP 500"
                                                        <?php if($fumigacione->producto == 'DDVP 500'): ?> selected <?php endif; ?>>
                                                        DDVP 500</option>
                                                    <option value="SIEGE"
                                                        <?php if($fumigacione->producto == 'SIEGE'): ?> selected <?php endif; ?>>
                                                        SIEGE</option>
                                                    <option value="MAXFORCE"
                                                        <?php if($fumigacione->producto == 'MAXFORCE'): ?> selected <?php endif; ?>>MAXFORCE
                                                    </option>
                                                    <option value="TALÓN BLOQUE"
                                                        <?php if($fumigacione->producto == 'TALÓN BLOQUE'): ?> selected <?php endif; ?>>TALÓN BLOQUE
                                                    </option>
                                                    <option value="STORM"
                                                        <?php if($fumigacione->producto == 'STORM'): ?> selected <?php endif; ?>>
                                                        STORM</option>
                                                    <option value="ARMA"
                                                        <?php if($fumigacione->producto == 'ARMA'): ?> selected <?php endif; ?>>
                                                        ARMA</option>
                                                    <option value="RODILON BLOQUE"
                                                        <?php if($fumigacione->producto == 'RODILON BLOQUE'): ?> selected <?php endif; ?>>RODILON BLOQUE
                                                    </option>
                                                    <option value="DIFARAT"
                                                        <?php if($fumigacione->producto == 'DIFARAT'): ?> selected <?php endif; ?>>DIFARAT</option>
                                                    <option value="C-REALB"
                                                        <?php if($fumigacione->producto == 'C-REALB'): ?> selected <?php endif; ?>>C-REALB</option>
                                                    <option value="BETA QUAT 4"
                                                        <?php if($fumigacione->producto == 'BETA QUAT 4'): ?> selected <?php endif; ?>>BETA QUAT 4
                                                    </option>
                                                    <option value="VIRTUAL"
                                                        <?php if($fumigacione->producto == 'VIRTUAL'): ?> selected <?php endif; ?>>VIRTUAL</option>
                                                    <option value="SAVAGE"
                                                        <?php if($fumigacione->producto == 'SAVAGE'): ?> selected <?php endif; ?>>
                                                        SAVAGE</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xs-12 col-sm-12 col-md-12 card-deck" hidden>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="insectosvoladores" name="insectosvoladores">
                                                    <label class="form-check-label" for="insectosvoladores">
                                                        Insectos Voladores
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="insectosrastreros" name="insectosrastreros">
                                                    <label class="form-check-label" for="insectosrastreros">
                                                        Insectos Rastreros
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="cucaracha" name="cucaracha">
                                                    <label class="form-check-label" for="cucaracha">
                                                        Cucaracha (Ger/Ori/Ame)
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="pulgas" name="pulgas">
                                                    <label class="form-check-label" for="pulgas">
                                                        Pulgas
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="mosca" name="mosca">
                                                    <label class="form-check-label" for="mosca">
                                                        Mosca
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="chinches" name="chinches">
                                                    <label class="form-check-label" for="chinches">
                                                        Chinches
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="aracnidos" name="aracnidos">
                                                    <label class="form-check-label" for="aracnidos">
                                                        Aracnidos
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="hormigas" name="hormigas">
                                                    <label class="form-check-label" for="hormigas">
                                                        Hormigas
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="termitas" name="termitas">
                                                    <label class="form-check-label" for="termitas">
                                                        Termitas
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="roedores" name="roedores">
                                                    <label class="form-check-label" for="roedores">
                                                        Roedores
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="alacranes" name="alacranes">
                                                    <label class="form-check-label" for="alacranes">
                                                        Alacranes
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="No"
                                                        checked id="carcamo" name="carcamo">
                                                    <label class="form-check-label" for="carcamo">
                                                        Carcamo
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        
                                        <div class="col-xs-12 col-sm-12 col-md-12 card-deck" hidden>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="insectosvoladores" name="insectosvoladores"
                                                        <?php if($fumigacione->insectosvoladores == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="insectosvoladores">
                                                        Insectos Voladores
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="insectosrastreros" name="insectosrastreros"
                                                        <?php if($fumigacione->insectosrastreros == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="insectosrastreros">
                                                        Insectos Rastreros
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="cucaracha" name="cucaracha"
                                                        <?php if($fumigacione->cucaracha == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="cucaracha">
                                                        Cucaracha (Ger/Ori/Ame)
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="pulgas" name="pulgas"
                                                        <?php if($fumigacione->pulgas == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="pulgas">
                                                        Pulgas
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="mosca" name="mosca"
                                                        <?php if($fumigacione->mosca == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="mosca">
                                                        Mosca
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="chinches" name="chinches"
                                                        <?php if($fumigacione->chinches == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="chinches">
                                                        Chinches
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="aracnidos" name="aracnidos"
                                                        <?php if($fumigacione->aracnidos == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="aracnidos">
                                                        Aracnidos
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="hormigas" name="hormigas"
                                                        <?php if($fumigacione->hormigas == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="hormigas">
                                                        Hormigas
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="termitas" name="termitas"
                                                        <?php if($fumigacione->termitas == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="termitas">
                                                        Termitas
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="roedores" name="roedores"
                                                        <?php if($fumigacione->roedores == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="roedores">
                                                        Roedores
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="alacranes" name="alacranes"
                                                        <?php if($fumigacione->alacranes == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="alacranes">
                                                        Alacranes
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="Si"
                                                        id="carcamo" name="carcamo"
                                                        <?php if($fumigacione->carcamo == 'Si'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="carcamo">
                                                        Carcamo
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <br>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="status">Status</label>
                                                <select name="status" id="status" class=" selectsearch">
                                                    <option disabled value="">Selecciona un Status</option>
                                                    <option <?php if($fumigacione->status == 'Realizado'): ?> selected <?php endif; ?>
                                                        value="Realizado">Realizado</option>
                                                    <option <?php if($fumigacione->status == 'Cancelado'): ?> selected <?php endif; ?>
                                                        value="Cancelado">Cancelado</option>
                                                    <option <?php if($fumigacione->status == 'Reprogramado'): ?> selected <?php endif; ?>
                                                        value="Reprogramado">Reprogramado</option>
                                                    <option <?php if($fumigacione->status == 'Pendiente'): ?> selected <?php endif; ?>
                                                        value="Pendiente">Pendiente</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="observaciones">Observaciones</label>
                                                <textarea name="observaciones" id="observaciones" class="form-control" rows="7"><?php echo e($fumigacione->observaciones); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Guardar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            $a = $a . 'a';
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/fumigaciones/index.blade.php ENDPATH**/ ?>