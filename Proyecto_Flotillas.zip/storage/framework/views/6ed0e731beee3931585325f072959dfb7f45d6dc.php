<?php $__env->startSection('title'); ?>
    Fumigaciones
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Fumigaciones de <?php echo e($unidad); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="card-body">
                    <a class="btn btn-danger" href="<?php echo e(route('clientes.show', $usuario = $unidad)); ?>">Regresar</a>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-warning" href="<?php echo e(route('fumigaciones.crear',$unidad)); ?>">Nuevo</a>
                            <table class="table table-striped mt-2" id="tabla">
                                <a class="btn btn-success" href="<?php echo e(route('fumigaciones.export')); ?>"><i
                                        class="fas fa-file-excel"></i></a>
                                <input type="text" class="form-control pull-right" style="width:20%" id="search"
                                    placeholder="Buscar....">
                                <thead style="background-color:#6777ef">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Identificador Fumigación</th>
                                    <th style="color:#fff;">Información</th>
                                    <th style="color:#fff;">Status</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php
                                        $a = 'a';
                                    ?>
                                    <?php $__currentLoopData = $fumigaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fumigacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($fumigacione->id); ?></td>
                                            <td><?php echo e($fumigacione->numerofumigacion); ?></td>
                                            
                                            <td>
                                                <button type="button" class="btn btn-primary"
                                                    onclick="$('#<?php echo e($a); ?>').modal('show')">
                                                    Detalles
                                                </button>
                                            </td>
                                            
                                            <td>
                                                <?php if($fumigacione->status == 'En Proceso'): ?>
                                                    <h5><span class="badge badge-warning"><?php echo e($fumigacione->status); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($fumigacione->status == 'Concluido'): ?>
                                                    <h5><span class="badge badge-success"><?php echo e($fumigacione->status); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($fumigacione->status == 'Por Confirmar'): ?>
                                                    <h5><span class="badge badge-warning"><?php echo e($fumigacione->status); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-info"
                                                    href="<?php echo e(route('fumigaciones.edit', $fumigacione->id)); ?>">
                                                    <i class="fas fa-edit"></i></a>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="$('#delete<?php echo e($a); ?>').modal('show')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php
                                            $a = $a . 'a';
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php
        $a = 'a';
    ?>
    <?php $__currentLoopData = $fumigaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fumigacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e($a); ?>" tabindex="-1" role="dialog" aria-labelledby="ModalDetallesTitle"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>
                                Información de la Fumigación: <?php echo e($fumigacione->numerofumigacion); ?></b></h5>
                        <button type="button" class="btn-close" onclick="$('#<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <b>Unidad:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->unidad); ?>

                        </li>
                        <br>
                        <b>Fumigador:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->id_fumigador); ?>

                        </li>
                        <br>
                        <b>Fecha Programada:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->fechaprogramada); ?>

                        </li>
                        <br>
                        <b>Fecha de la Ultima Fumigaciòn:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->fechaultimafumigacion); ?>

                        </li>
                        <br>
                        <b>Lugar del Servicio:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->lugardelservicio); ?>

                        </li>
                        <br>
                        <b>Numero de Visitas:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->numerodevisitas); ?>

                        </li>
                        <br>
                        <b>Costo:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->costo); ?>

                        </li>
                        <br>
                        <b>Satisfacciòn del Servicio:</b>
                        <li class="list-group-item">
                            <?php echo e($fumigacione->satisfaccionservicio); ?>

                        </li>
                        <br>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e($a); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="delete<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar la Fumigación
                                <?php echo e($fumigacione->numerofumigacion); ?>?</b></h5>
                        <button type="button" class="btn-close" onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('fumigaciones.destroy', $fumigacione->id)); ?>"method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            $a = $a . 'a';
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/fumigaciones/index.blade.php ENDPATH**/ ?>