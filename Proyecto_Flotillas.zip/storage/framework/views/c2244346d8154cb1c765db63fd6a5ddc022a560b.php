<?php $__env->startSection('title'); ?>
    REPORTE SEMANAL
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Reporte Fumigaciones Realizadas</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success"
                                            dir="<?php echo e(route('tabla_reportes.reporte_semanalexcel')); ?>">
                                            <i class="fas fa-file-excel"></i> Excel
                                        </button>
                                        <button type="submit" class="btn btn-danger"
                                            dir="<?php echo e(route('pdf.reportes_semanalpdf')); ?>">
                                            <i class="fas fa-file-pdf"></i> PDF
                                        </button>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="card-deck mt-6">
                                        <div class="card col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group ">
                                                <label>Filtro por Fechas</label>
                                                <div class="input-group">
                                                    <label for="filtrofechainicio" style="width:55%">Fecha Inicio</label>
                                                    <label for="filtrofechafinal" style="width:45%">Fecha Final</label>
                                                </div>
                                                <div class="input-group">
                                                    <input type="date" name="filtrofechainicio" class="form-control"
                                                        style="width:40%">
                                                    <span id="boot-icon" class="bi bi-dash-square-fill"
                                                        style="font-size: 2rem; color: rgb(84, 84, 84);"></span>
                                                    <input type="date" name="filtrofechafinal" class="form-control"
                                                        style="width:40%">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('particular-rol')): ?>
                                    <div class="row">
                                        <div class="card-deck mt-6">
                                            <div class="card col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="filtrocli">Filtro Clientes:</label>
                                                    <input type="text" name="filtrocli" id="filtrocli" class="form-control"
                                                        value="<?php echo e($clientes); ?>" readonly="readonly" style="width:100%">
                                                </div>
                                            </div>
                                            <div class="card col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="filtrounid">Filtro Unidades</label>
                                                    <select name="filtrounid" id="filtrounid" readonly="readonly"
                                                        class=" selectsearch" style="width:100%">
                                                        <option selected value="todos">Todas Las Unidades</option>
                                                        <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                                                <option value="<?php echo e($unidade->serieunidad); ?>">
                                                                    <?php echo e($unidade->serieunidad); ?></option>';
                                                            <?php endif; ?>
                                                            <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                                                <option value="<?php echo e($unidade->direccion); ?>">
                                                                    <?php echo e($unidade->direccion); ?></option>';
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                <?php endif; ?>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general-rol')): ?>
                                    <div class="row">
                                        <div class="card-deck mt-6">
                                            <div class="card col-xs-12 col-sm-12 col-md-12">
                                                <div class="input-group">
                                                    <label class="label" for="filtrocli">Filtro Clientes</label>
                                                    <select name="filtrocli" id="filtrocli" 
                                                        class="form-select form-select-sm mb-3"
                                                        aria-label=".form-select-sm example" style="width:100%">
                                                        <option value="todos">Todos los Clientes</option>
                                                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($cliente->nombrecompleto); ?>">
                                                                <?php echo e($cliente->nombrecompleto); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="card col-xs-12 col-sm-12 col-md-12">
                                                <div class="input-group" id="unidades_opciones">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="card-deck mt-6">
                                        <div class="card col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="filtrotuni">Filtro Tipo de Unidad</label>
                                                <select name="filtrotuni" id="filtrotuni" class=" selectsearch"
                                                    style="width:100%">
                                                    <option selected value="Ambas">Ambas Unidades</option>
                                                    <option value="Habitacion">Habitacionales</option>
                                                    <option value="Vehiculo">Vehiculares</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="card-deck mt-6">
                                        <div class="card col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="filtrofumigador">Filtro Fumigadores</label>
                                                <select name="filtrofumigador" id="filtrofumigador" readonly="readonly"
                                                    class=" selectsearch" style="width:100%">
                                                    <option selected value="todos">Todos los Fumigadores</option>
                                                    <?php $__currentLoopData = $fumigadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fumigador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($fumigador->nombrecompleto); ?>">
                                                            <?php echo e($fumigador->nombrecompleto); ?></option>';
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>
                            </form>
                            <br>
                            <table id='tablas-style' class="table table-striped mt-2">
                                <thead style="background-color:#6777ef">
                                    <th style="color:#fff;">Id CLiente</th>
                                    <th style="color:#fff;">CLiente</th>
                                    <th style="color:#fff;">Razon Social Cliente</th>
                                    <th style="color:#fff;">Dirección Fisica</th>
                                    <th style="color:#fff;">Folio Fumigación</th>
                                    <th style="color:#fff;">Unidad</th>
                                    <th style="color:#fff;">Fumigador</th>
                                    <th style="color:#fff;">Fecha Programada</th>
                                    <th style="color:#fff;">Status</th>
                                    <th style="color:#fff;">Marca</th>
                                    <th style="color:#fff;">Serie Unidad/Dirección</th>
                                    <th style="color:#fff;">Año Unidad</th>
                                    <th style="color:#fff;">Placas</th>
                                    <th style="color:#fff;">Tipo Unidad</th>
                                    <th style="color:#fff;">Razon Social Unidad</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $fumigaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fumigacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($fumigacion->id); ?></td>
                                            <td><?php echo e($fumigacion->nombrecompleto); ?></td>
                                            <td><?php echo e($fumigacion->razonsocial); ?></td>
                                            <td><?php echo e($fumigacion->direccionfisica); ?></td>
                                            <td><?php echo e($fumigacion->numerofumigacion); ?></td>
                                            <td><?php echo e($fumigacion->unidad); ?></td>
                                            <td><?php echo e($fumigacion->id_fumigador); ?></td>
                                            <td><?php echo e($fumigacion->fechaprogramada); ?></td>
                                            <td><?php echo e($fumigacion->status); ?></td>
                                            <td><?php echo e($fumigacion->marca); ?></td>
                                            <td><?php echo e($fumigacion->serieunidad); ?></td>
                                            <td><?php echo e($fumigacion->añounidad); ?></td>
                                            <td><?php echo e($fumigacion->placas); ?></td>
                                            <td><?php echo e($fumigacion->tipo); ?></td>
                                            <td><?php echo e($fumigacion->razonsocialunidad); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        /* ==================== AJAX_UNIDADES ==================== */
        function recargarLista() {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: "POST",
                url: "<?php echo e(route('pdf.datos_unidades_ambas')); ?>",
                data: 'datos_unidad=' + $('#filtrocli').val(),
                success: function(r) {
                    $('#unidades_opciones').html(r);
                },
                error: function() {
                    alert("ERROR AL CARGAR UNIDADES");
                }
            });
        }
        /* =============================================== */
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            /* ------------------ CARGAR UNIDADES ------------------------------------------- */
            recargarLista();
            $('#filtrocli').change(function() {
                recargarLista();
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $("button[type=submit]").click(function(e) {
                e.preventDefault();
                var accion = $(this).attr('dir'),
                    $form = $(this).closest('form');
                if (typeof accion !== 'undefined') {
                    $form.attr('action', accion);
                }
                $form.submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/tabla_reportes/reporte_semanal.blade.php ENDPATH**/ ?>