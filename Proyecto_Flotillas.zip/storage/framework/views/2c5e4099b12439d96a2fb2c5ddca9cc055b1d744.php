<?php $__env->startSection('css'); ?>
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    REPORTE PREVENTIVO
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Reporte Preventivo Vehicular</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table id='tablas-style' class="table table-striped mt-2" id="tabla">
                                <a class="btn btn-success"><i class="fas fa-file-excel"></i></a>
                                
                                <thead style="background-color:#6777ef">
                                    <th style="color:#fff;">Placas</th>
                                    <th style="color:#fff;">Cliente</th>
                                    <th style="color:#fff;">Serie Unidad</th>
                                    <th style="color:#fff;">Marca</th>
                                    <th style="color:#fff;">Año Unidad</th>
                                    <th style="color:#fff;">Tipo Unidad</th>
                                    <th style="color:#fff;">Razon Social</th>
                                </thead>
                                <tbody>
                                    <?php
                                        $a = 'a';
                                        use App\Models\Verificacione;
                                        $verificaciones = Verificacione::all();
                                    ?>
                                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($unidade->placas); ?></td>
                                            <td><?php echo e($unidade->cliente); ?></td>
                                            <td><?php echo e($unidade->serieunidad); ?></td>
                                            <td><?php echo e($unidade->marca); ?></td>
                                            <td><?php echo e($unidade->añounidad); ?></td>
                                            <td><?php echo e($unidade->tipounidad); ?></td>
                                            <td><?php echo e($unidade->razonsocialunidad); ?></td>
                                            
                                            

                                            
                                        </tr>
                                        <?php
                                            $a = $a . 'a';
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src='https://code.jquery.com/jquery-3.5.1.js'></script>
    <script src='https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js'></script>
    <script src='https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js'></script>
    <script>
        $(document).ready(function() {
            $('#tablas-style').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/tabla_reportes/reporte_preventivo.blade.php ENDPATH**/ ?>