<?php $__env->startSection('css'); ?>
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    REPORTE OPERADORES
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Reporte Individual Operador</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table id='tablas-style' class="table table-striped mt-2" id="tabla">
                                <a class="btn btn-success"><i class="fas fa-file-excel"></i></a>
                               
                                <thead style="background-color:#6777ef">
                                    <th style="color:#fff;">Cliente</th>
                                    <th style="color:#fff;">Nombre Operador</th>
                                    <th style="color:#fff;">No. Licencia</th>
                                    <th style="color:#fff;">Vencimiento Licencia</th>
                                    <th style="color:#fff;">Vencimiento Apto</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operadore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($operadore->cliente); ?></td>
                                            <td><?php echo e($operadore->nombreoperador); ?></td>
                                            <td><?php echo e($operadore->nolicencia); ?></td>
                                            <td><?php echo e($operadore->fechavencimientolicencia); ?></td>
                                            <td><?php echo e($operadore->fechavencimientomedico); ?></td>
                                            
                                            

                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src='https://code.jquery.com/jquery-3.5.1.js'></script>
    <script src='https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js'></script>
    <script src='https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js'></script>
    <script>
        $(document).ready(function() {
            $('#tablas-style').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/tabla_reportes/reporte_operador.blade.php ENDPATH**/ ?>