<?php $__env->startSection('title'); ?>
    Unidades
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Editar Unidad de <?php echo e($unidade->cliente); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-danger"
                                href="<?php echo e(route('clientes.show', $usuario = $unidade->cliente)); ?>">Regresar</a>
                        </div>
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-danger"><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <form action="<?php echo e(route('unidades.update', $unidade->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                
                                <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                    <h4 class="form-check-label">Tipo de Unidad</h4>
                                    <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="tipo" id="habitacion"
                                                value="Unidad Habitacional o Comercial" checked>
                                            <label class="form-check-label" for="habitacion">
                                                Unidad Habitacional o Comercial
                                            </label>
                                        </div>
                                    <?php else: ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="tipo" id="habitacion"
                                                value="Unidad Habitacional o Comercial">
                                            <label class="form-check-label" for="habitacion">
                                                Unidad Habitacional o Comercial
                                            </label>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="tipo" id="vehiculo"
                                                value="Unidad Vehicular" checked>
                                            <label class="form-check-label" for="vehiculo">
                                                Unidad Vehicular
                                            </label>
                                        </div>
                                    <?php else: ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="tipo" id="vehiculo"
                                                value="Unidad Vehicular">
                                            <label class="form-check-label" for="vehiculo">
                                                Unidad Vehicular
                                            </label>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                            <div class="form-group">
                                                <label for="cliente">cliente</label>
                                                <input type="text" name="cliente" class="form-control"
                                                    value="<?php echo e($unidade->cliente); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="razonsocialunidad">Razon Social</label>
                                                <input type="text" name="razonsocialunidad" class="form-control"
                                                    value="<?php echo e($unidade->razonsocialunidad); ?>">
                                            </div>
                                        </div>
                                        <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="seguro">seguro</label>
                                                    <input type="text" name="seguro" class="form-control"
                                                        value="<?php echo e($unidade->seguro); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="verificacion">verificacion</label>
                                                    <input type="text" name="verificacion" class="form-control"
                                                        value="<?php echo e($unidade->verificacion); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="verificacion2">verificacion2</label>
                                                    <input type="text" name="verificacion2" class="form-control"
                                                        value="<?php echo e($unidade->verificacion2); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="mantenimiento">mantenimiento</label>
                                                    <input type="text" name="mantenimiento" class="form-control"
                                                        value="<?php echo e($unidade->mantenimiento); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="seguro_fecha">seguro_fecha</label>
                                                    <input type="text" name="seguro_fecha" class="form-control"
                                                        value="<?php echo e($unidade->seguro_fecha); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="verificacion_fecha">verificacion_fecha</label>
                                                    <input type="text" name="verificacion_fecha" class="form-control"
                                                        value="<?php echo e($unidade->verificacion_fecha); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="verificacion_fecha2">verificacion_fecha2</label>
                                                    <input type="text" name="verificacion_fecha2" class="form-control"
                                                        value="<?php echo e($unidade->verificacion_fecha2); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="mantenimiento_fecha">mantenimiento_fecha</label>
                                                    <input type="text" name="mantenimiento_fecha" class="form-control"
                                                        value="<?php echo e($unidade->mantenimiento_fecha); ?>">
                                                </div>
                                            </div>
                                            
                                            
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="serieunidad">No. Serie</label>
                                                    <input type="text" name="serieunidad" class="form-control"
                                                        value="<?php echo e($unidade->serieunidad); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="marca">Marca</label>
                                                    <input type="text" name="marca" class="form-control"
                                                        value="<?php echo e($unidade->marca); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="submarca">Sub Marca</label>
                                                    <input type="text" name="submarca" class="form-control"
                                                        value="<?php echo e($unidade->submarca); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="añounidad">Año</label>
                                                    <input type="number" min="1900" max="2099" step="1"
                                                        name="añounidad" class="form-control"
                                                        value="<?php echo e($unidade->añounidad); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="tipounidad">Tipo</label>
                                                    <input type="text" name="tipounidad" class="form-control"
                                                        value="<?php echo e($unidade->tipounidad); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="placas">Placas</label>
                                                    <input type="text" name="placas" class="form-control"
                                                        value="<?php echo e($unidade->placas); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="tipomantenimiento">Tipo de Mantenimiento</label>
                                                    <select name="tipomantenimiento" id="tipomantenimiento"
                                                        class=" selectsearch">
                                                        <option disabled value="">Selecciona Status</option>
                                                        <option value="Kilometraje"
                                                            <?php if($unidade->tipomantenimiento == 'Kilometraje'): ?> selected <?php endif; ?>>Mantenimiento
                                                            por Kilometraje
                                                        </option>
                                                        <option value="Fecha"
                                                            <?php if($unidade->tipomantenimiento == 'Fecha'): ?> selected <?php endif; ?>> Mantenimiento
                                                            por Fecha
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <br>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="frecuencia_mante">Frecuencia de Mantenimiento</label>
                                                    <input type="number" min="1"step="1"
                                                        name="frecuencia_mante" class="form-control"
                                                        placeholder="Frecuencia por Meses o Kilometros"
                                                        value="<?php echo e($unidade->frecuencia_mante); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="status">Status de Servivio</label>
                                                    <select name="status" id="status" class=" selectsearch">
                                                        <option disabled value="">Selecciona Status</option>
                                                        <option value="Status 1"
                                                            <?php if($unidade->status == 'Status 1'): ?> selected <?php endif; ?>>Status 1
                                                        </option>
                                                        <option value="Status 2"
                                                            <?php if($unidade->status == 'Status 2'): ?> selected <?php endif; ?>>Status 2
                                                        </option>
                                                        <option value="Status 3"
                                                            <?php if($unidade->status == 'Status 3'): ?> selected <?php endif; ?>>Status 3
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                            

                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="cp">Codigo Postal</label>
                                                    <input type="number" min="10000" max="99999" step="1"
                                                        name="cp" class="form-control" value="<?php echo e($unidade->cp); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="direccion">Dirección</label>
                                                    <input type="text" name="direccion" class="form-control"
                                                        value="<?php echo e($unidade->direccion); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="calle">Calle</label>
                                                    <input type="text" name="calle" class="form-control"
                                                        value="<?php echo e($unidade->calle); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="ciudad">Ciudad</label>
                                                    <input type="text" name="ciudad" class="form-control"
                                                        value="<?php echo e($unidade->ciudad); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <div class="form-group">
                                                    <label for="responsable">Responsable</label>
                                                    <input type="text" name="responsable" class="form-control"
                                                        value="<?php echo e($unidade->responsable); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-12" hidden>
                                                <div class="form-group">
                                                    <label for="lapsofumigacion">lapsofumigacion</label>
                                                    <input type="text" name="lapsofumigacion" class="form-control"
                                                        value="Sin Fecha de Fumigación">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <div class="form-group">
                                                <label for="frecuencia_fumiga">Frecuencia de Fumigacion</label>
                                                <input type="number" min="1" step="1"
                                                    name="frecuencia_fumiga" class="form-control"
                                                    placeholder="Frecuencia en meses"
                                                    value="<?php echo e($unidade->frecuencia_fumiga); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                            <button type="submit" class="btn btn-primary">Guardar</button>
                                        </div>
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        //----------------------------------------- MOSTRAR TIPO DE UNIDAD -----------------------------------------
        var habitacion = document.getElementById('unidadv');
        document.getElementById('habitacion').addEventListener('click', function(e) {
            habitacion.style.display = 'none';
        });
        document.getElementById('vehiculo').addEventListener('click', function(e) {
            habitacion.style.display = 'inline';
        });
        /* llllllllllllllllllllllllllllllllllllllllllllllllllll */
        var vehiculo = document.getElementById('unidadh');
        document.getElementById('habitacion').addEventListener('click', function(e) {
            vehiculo.style.display = 'inline';
        });
        document.getElementById('vehiculo').addEventListener('click', function(e) {
            vehiculo.style.display = 'none';
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/unidades/editar.blade.php ENDPATH**/ ?>