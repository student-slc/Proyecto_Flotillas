
<?php $__env->startSection('title'); ?>
    Reportes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <?php if($color == 'sin mantenimiento'): ?>
                <?php
                    $estado = 'Sin Mantenimiento';
                ?>
            <?php endif; ?>
            <?php if($color == 'azul'): ?>
                <?php
                    $estado = '500 km';
                ?>
            <?php endif; ?>
            <?php if($color == 'verde'): ?>
                <?php
                    $estado = '300 a 500 km';
                ?>
            <?php endif; ?>
            <?php if($color == 'amarillo'): ?>
                <?php
                    $estado = '100 a 300 km';
                ?>
            <?php endif; ?>
            <?php if($color == 'rojo'): ?>
                <?php
                    $estado = '1 a 100 km';
                ?>
            <?php endif; ?>
            <?php if($color == 'expirado'): ?>
                <?php
                    $estado = 'Mantenimiento Expirado';
                ?>
            <?php endif; ?>
            <h3 class="page__heading">Mantenimiento por Kilometraje de Todas Las unidades en: <?php echo e($estado); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="card-body">
                    <a class="btn btn-danger" href="<?php echo e(route('home')); ?>">Regresar</a>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-striped mt-2" id="tabla">
                                <thead style="background-color:#95b8f6">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Cliente</th>
                                    <th style="color:#fff;">No. Serie</th>
                                    <th style="color:#fff;">Información</th>
                                    <th style="color:#fff;">Estado Mantenimiento</th>
                                </thead>
                                <tbody>
                                    <?php
                                        $a = 'a';
                                        $pos = 0;
                                        $cont = 0;
                                    ?>
                                    
                                    <?php if($color == 'sin mantenimiento'): ?>
                                        <?php
                                            $pos = 1;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'azul'): ?>
                                        <?php
                                            $pos = 2;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'verde'): ?>
                                        <?php
                                            $pos = 3;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'amarillo'): ?>
                                        <?php
                                            $pos = 4;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'rojo'): ?>
                                        <?php
                                            $pos = 5;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'expirado'): ?>
                                        <?php
                                            $pos = 6;
                                        ?>
                                    <?php endif; ?>
                                    <?php
                                        if ($calculo[$pos][0] == 'vacio') {
                                            $cont = 10;
                                            $opc_2 = 0;
                                        } else {
                                            $opc_2 = count($calculo[$pos]);
                                        }
                                    ?>
                                    
                                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($opc_2 > $cont && $unidade->tipo == 'Unidad Vehicular'): ?>
                                            <?php if($calculo[$pos][$cont] == $unidade->serieunidad && $unidade->tipomantenimiento == 'Kilometraje'): ?>
                                                <?php
                                                    if ($opc_2 == 1) {
                                                        $cont = $cont + 10;
                                                    } else {
                                                        $cont = $cont + 1;
                                                    }
                                                ?>
                                                <tr>
                                                    <td style="display: none;"><?php echo e($unidade->id); ?></td>
                                                    <td><?php echo e($unidade->cliente); ?></td>
                                                    <td><?php echo e($unidade->serieunidad); ?></td>
                                                    
                                                    <td>
                                                        <button type="button" class="btn btn-primary"
                                                            onclick="$('#<?php echo e($a); ?>').modal('show')">
                                                            Detalles
                                                        </button>
                                                    </td>
                                                    
                                                    <td>
                                                        <h6>
                                                            <?php if($unidade->mantenimiento == 'Sin Mantenimiento'): ?>
                                                                <span class="badge badge-danger">SIN MANTENIMIENTO</span>
                                                            <?php else: ?>
                                                                <?php if($unidade->tipomantenimiento == 'Kilometraje'): ?>
                                                                    <?php
                                                                        $km_contador = $unidade->kilometros_contador;
                                                                        $frecuencia = $unidade->frecuencia_mante;
                                                                        $km_actual = $unidade->kilometros_actuales;
                                                                        $diferencia = $frecuencia + $km_actual - $km_contador;
                                                                    ?>
                                                                    <?php if($km_contador >= $frecuencia + $km_actual): ?>
                                                                        <span class="badge badge-danger">
                                                                            MANTENIMIENTO EXPIRADO</span>
                                                                    <?php endif; ?>
                                                                    <?php if($km_contador < $frecuencia + $km_actual): ?>
                                                                        <?php
                                                                            $diferencia = $frecuencia + $km_actual - $km_contador;
                                                                        ?>
                                                                        <?php if($diferencia >= 1 && $diferencia < 100): ?>
                                                                            <span class="badge badge-danger">
                                                                                <?php echo e($diferencia); ?> KM
                                                                                PARA EXPIRAR</span>
                                                                        <?php endif; ?>
                                                                        <?php if($diferencia >= 100 && $diferencia < 300): ?>
                                                                            <span class="badge badge-warning">
                                                                                <?php echo e($diferencia); ?> KM
                                                                                PARA EXPIRAR</span>
                                                                        <?php endif; ?>
                                                                        <?php if($diferencia >= 300 && $diferencia < 500): ?>
                                                                            <span class="badge badge-success">
                                                                                <?php echo e($diferencia); ?> KM
                                                                                PARA EXPIRAR</span>
                                                                        <?php endif; ?>
                                                                        <?php if($diferencia >= 500): ?>
                                                                            <span class="badge badge-primary">
                                                                                <?php echo e($diferencia); ?> KM
                                                                                PARA EXPIRAR</span>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </h6>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php
                                            $a = $a . 'a';
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php
        $a = 'a';
    ?>
    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e($a); ?>" tabindex="-1" role="dialog" aria-labelledby="ModalDetallesTitle"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>Informacion de
                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                    <?php echo e($unidade->direccion); ?>

                                <?php endif; ?>
                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                    <?php echo e($unidade->serieunidad); ?>

                                <?php endif; ?>
                            </b></h5>
                        <button type="button" class="btn-close" onclick="$('#<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                            <b>Cliente:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cliente); ?>

                            </li>
                            <br>
                            <b>Marca:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->marca); ?>

                            </li>
                            <br>
                            <b>SubMarca:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->submarca); ?>

                            </li>
                            <br>
                            <b>Año de la Unidad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->añounidad); ?>

                            </li>
                            <br>
                            <b>Kilometraje:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->kilometros_contador); ?>

                            </li>
                            <br>
                            <b>Tipo de Unidad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->tipounidad); ?>

                            </li>
                            <br>
                            <b>Razon Social:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->razonsocialunidad); ?>

                            </li>
                            <br>
                            <b>Placas:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->placas); ?>

                            </li>
                            <br>
                            <b>Vencimiento Seguro:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->seguro_fecha); ?>

                            </li>
                            <br>
                            <b>Vencimiento Verificación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->verificacion_fecha); ?>

                            </li>
                            <br>
                            <?php if($unidade->tipomantenimiento == 'Fecha'): ?>
                                <b>Tipo de Mantenimiento:</b>
                                <li class="list-group-item">
                                    Mantenimiento por Fecha de Vencimiento
                                </li>
                                <br>
                            <?php endif; ?>
                            <?php if($unidade->tipomantenimiento == 'Kilometraje'): ?>
                                <b>Tipo de Mantenimiento:</b>
                                <li class="list-group-item">
                                    Mantenimiento por Kilometraje
                                </li>
                                <br>
                            <?php endif; ?>
                            <b>Vencimiento Fumigación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->lapsofumigacion); ?>

                            </li>
                            <br>
                            <b>Status:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->status); ?>

                            </li>
                            <br>
                        <?php endif; ?>
                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                            <b>Cliente:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cliente); ?>

                            </li>
                            <br>
                            <b>Codigo Postal:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cp); ?>

                            </li>
                            <br>
                            <b>Dirección:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->direccion); ?>

                            </li>
                            <br>
                            <b>Calle:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->calle); ?>

                            </li>
                            <br>
                            <b>Ciudad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->ciudad); ?>

                            </li>
                            <br>
                            <b>Responsable:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->responsable); ?>

                            </li>
                            <br>
                            <b>Razon Social:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->razonsocialunidad); ?>

                            </li>
                            <br>
                            <b>Vencimiento Fumigación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->lapsofumigacion); ?>

                            </li>
                            <br>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e($a); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
            $a = $a . 'a';
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/reportes/kmantenimiento.blade.php ENDPATH**/ ?>