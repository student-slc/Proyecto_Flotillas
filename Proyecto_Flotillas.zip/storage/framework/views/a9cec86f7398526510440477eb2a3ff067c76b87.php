<?php $__env->startSection('title'); ?>
    Reportes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <?php if($color == 'sin verificacion'): ?>
                <?php
                    $estado = 'Sin Verificacion';
                ?>
            <?php endif; ?>
            <?php if($color == 'azul'): ?>
                <?php
                    $estado = '9 a 12 meses para expirar';
                ?>
            <?php endif; ?>
            <?php if($color == 'verde'): ?>
                <?php
                    $estado = '5 a 8 meses para expirar';
                ?>
            <?php endif; ?>
            <?php if($color == 'amarillo'): ?>
                <?php
                    $estado = '2 a 4 meses para expirar';
                ?>
            <?php endif; ?>
            <?php if($color == 'rojo'): ?>
                <?php
                    $estado = '1 mes para expirar';
                ?>
            <?php endif; ?>
            <?php if($color == 'expirado'): ?>
                <?php
                    $estado = 'Verificacion Expirada';
                ?>
            <?php endif; ?>
            <h3 class="page__heading">Verificaciones Ambientales de Todas Las unidades en: <?php echo e($estado); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="card-body">
                    <a class="btn btn-danger" href="<?php echo e(route('home')); ?>">Regresar</a>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-striped mt-2" id="tabla">
                                <a class="btn btn-success" ><i class="fas fa-file-excel"></i></a>
                                <input type="text" class="form-control pull-right" style="width:20%" id="search"
                                    placeholder="Buscar....">
                                <thead style="background-color:#6777ef">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Cliente</th>
                                    <th style="color:#fff;">No. Serie</th>
                                    <th style="color:#fff;">Información</th>
                                    <th style="color:#fff;">Estado Verificacion</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php
                                        $a = 'a';
                                        $pos = 0;
                                        $cont = 0;
                                    ?>
                                    
                                    <?php if($color == 'sin verificacion'): ?>
                                        <?php
                                            $pos = 1;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'azul'): ?>
                                        <?php
                                            $pos = 2;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'verde'): ?>
                                        <?php
                                            $pos = 3;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'amarillo'): ?>
                                        <?php
                                            $pos = 4;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'rojo'): ?>
                                        <?php
                                            $pos = 5;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($color == 'expirado'): ?>
                                        <?php
                                            $pos = 6;
                                        ?>
                                    <?php endif; ?>
                                    <?php
                                        if ($calculo[$pos][0] == 'vacio') {
                                            $cont = 10;
                                            $opc_2 = 0;
                                        } else {
                                            $opc_2 = count($calculo[$pos]);
                                        }
                                    ?>
                                    
                                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($opc_2 > $cont && $unidade->tipo == 'Unidad Vehicular'): ?>
                                            <?php if($calculo[$pos][$cont] == $unidade->serieunidad): ?>
                                                <?php
                                                    if ($opc_2 == 1) {
                                                        $cont = $cont + 10;
                                                    } else {
                                                        $cont = $cont + 1;
                                                    }
                                                ?>
                                                <tr>
                                                    <td style="display: none;"><?php echo e($unidade->id); ?></td>
                                                    <td><?php echo e($unidade->cliente); ?></td>
                                                    <td><?php echo e($unidade->serieunidad); ?></td>
                                                    
                                                    <td>
                                                        <button type="button" class="btn btn-primary"
                                                            onclick="$('#<?php echo e($a); ?>').modal('show')">
                                                            Detalles
                                                        </button>
                                                    </td>
                                                    
                                                    <td>
                                                        <?php if($unidade->verificacion == 'Sin Verificación'): ?>
                                                            <h5><span class="badge badge-danger"><?php echo e($unidade->verificacion); ?></span>
                                                            </h5>
                                                        <?php else: ?>
                                                            
                                                            <?php
                                                                /* FECHA LICENCIA */
                                                                $vencimiento_dia = substr($unidade->verificacion_fecha, 8, 2);
                                                                $vencimiento_mes = substr($unidade->verificacion_fecha, 5, 2);
                                                                $vencimiento_año = substr($unidade->verificacion_fecha, 0, 4);
                                                                /* FECHA ACTUAL */
                                                                $año_actual = date('Y');
                                                                $mes_actual = date('n');
                                                                $dia_actual = date('d');
                                                                /* OBTIENE LA DIFERENCIA DE AÑO ENTRE FECHA ACTUAL Y FECHA A VENCER */
                                                                $diferencia_año = (int) $vencimiento_año - (int) $año_actual;
                                                                /* CALCULO DE NUMERO DE MESES ENTRE FECHA ACTUAL Y VENCIMIENTO */
                                                                $uno = 'nulo';
                                                                $calcular = 0;
                                                                if ($diferencia_año >= 1) {
                                                                    $meses = $diferencia_año * 12 + 12;
                                                                    $operacion_1 = $meses - (int) $mes_actual;
                                                                    $operacion_2 = 12 - (int) $vencimiento_mes;
                                                                    $operacion_3 = $operacion_1 - $operacion_2;
                                                                    $meses = $operacion_3;
                                                                } else {
                                                                    $meses = (int) $vencimiento_mes - (int) $mes_actual;
                                                                }
                                                                if ((int) $año_actual == (int) $vencimiento_año && (int) $mes_actual == (int) $vencimiento_mes) {
                                                                    $uno = 'uno';
                                                                    $calcular = 0;
                                                                } else {
                                                                    $cantidaddias = cal_days_in_month(CAL_GREGORIAN, $mes_actual, $año_actual);
                                                                    $direstantes = (int) $cantidaddias - (int) $dia_actual;
                                                                    $calcular = $direstantes + (int) $vencimiento_dia;
                                                                }
                                                                /* CALCULO DE DIAS EXACTOS */
                                                                $dias_exactos = 0;
                                                                $contador_1 = 0;
                                                                $contador_2 = 0;
                                                                $cuenta_mes = $mes_actual;
                                                                $operacion_1 = 0;
                                                                $mes_contador = 0;
                                                                for ($i = 0; $i <= $meses; $i++) {
                                                                    if ($uno == 'uno') {
                                                                        $dias_exactos = (int) $vencimiento_dia - (int) $dia_actual;
                                                                        $i = $meses + 1;
                                                                    } else {
                                                                        if ($contador_1 == 0) {
                                                                            $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                            $operacion_2 = (int) $operacion_1 - (int) $dia_actual;
                                                                            $dias_exactos = $dias_exactos + $operacion_2;
                                                                            $contador_1 = 1;
                                                                        } else {
                                                                            if ($i == $meses) {
                                                                                $dias_exactos = $dias_exactos + (int) $vencimiento_dia;
                                                                            } else {
                                                                                $operacion_1 = cal_days_in_month(CAL_GREGORIAN, $cuenta_mes, $año_actual + $contador_2);
                                                                                $dias_exactos = $dias_exactos + (int) $operacion_1;
                                                                                $mes_contador = $mes_contador + 1;
                                                                            }
                                                                        }
                                                                        if ($cuenta_mes == 12) {
                                                                            $contador_2 = $contador_2 + 1;
                                                                            $cuenta_mes = 1;
                                                                        } else {
                                                                            $cuenta_mes = $cuenta_mes + 1;
                                                                        }
                                                                    }
                                                                }
                                                                /* CALCULO DE MESES EXACTOS */
                                                                $dias_resto = $calcular;
                                                                $opc = 2;
                                                                for ($i = 0; $i <= $opc; $i++) {
                                                                    if ($calcular >= 30) {
                                                                        $mes_contador = $mes_contador + 1;
                                                                        $calcular = $calcular - 30;
                                                                    }
                                                                }
                                                            ?>
                                                            
                                                            
                                                            <h5>
                                                                <?php if($mes_contador >= 9): ?>
                                                                    <span class="badge badge-primary">
                                                                       Expira
                                                                            en:
                                                                            <?php echo e($mes_contador); ?> meses
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador >= 5 && $mes_contador <= 8): ?>
                                                                    <span class="badge badge-success">
                                                                        Expira
                                                                            en:
                                                                            <?php echo e($mes_contador); ?> meses
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador >= 2 && $mes_contador <= 4): ?>
                                                                    <span class="badge badge-warning">
                                                                        Expira
                                                                            en:
                                                                            <?php echo e($mes_contador); ?> meses
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 1 && $uno == 'nulo'): ?>
                                                                    <?php if($calcular == 0): ?>
                                                                        <span class="badge badge-danger">
                                                                            Expira
                                                                                en:
                                                                                <?php echo e($mes_contador); ?> mes
                                                                            </span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">
                                                                            Expira
                                                                                en:
                                                                                <?php echo e($mes_contador); ?> mes
                                                                                <br>y <?php echo e($calcular); ?> dias
                                                                            </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 1 && $uno == 'uno'): ?>
                                                                    <span class="badge badge-danger">
                                                                        Expira
                                                                            en:
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 0 && $dias_exactos > 0): ?>
                                                                    <span class="badge badge-danger">
                                                                        Expira
                                                                            en:
                                                                            <?php echo e($dias_exactos); ?> dias
                                                                        </span>
                                                                <?php endif; ?>
                                                                <?php if($mes_contador == 0 && $dias_exactos <= 0): ?>
                                                                    <span class="badge badge-danger">
                                                                            VERIFICACIÓN
                                                                            <br> EXPIRADA
                                                                        </span>
                                                                <?php endif; ?>
                                                            </h5>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a class="btn btn-info"
                                                            href="<?php echo e(route('unidades.edit', $unidade->id)); ?>">
                                                            <i class="fas fa-edit"></i></a>
                                                        <button type="submit" class="btn btn-danger"
                                                            onclick="$('#delete<?php echo e($a); ?>').modal('show')">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php
                                            $a = $a . 'a';
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php
        $a = 'a';
    ?>
    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e($a); ?>" tabindex="-1" role="dialog" aria-labelledby="ModalDetallesTitle"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>Informacion de
                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                    <?php echo e($unidade->direccion); ?>

                                <?php endif; ?>
                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                    <?php echo e($unidade->serieunidad); ?>

                                <?php endif; ?>
                            </b></h5>
                        <button type="button" class="btn-close" onclick="$('#<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                            <b>Marca:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->marca); ?>

                            </li>
                            <br>
                            <b>SubMarca:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->submarca); ?>

                            </li>
                            <br>
                            <b>Año de la Unidad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->añounidad); ?>

                            </li>
                            <br>
                            <b>Tipo de Unidad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->tipounidad); ?>

                            </li>
                            <br>
                            <b>Razon Social:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->razonsocialunidad); ?>

                            </li>
                            <br>
                            <b>Placas:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->placas); ?>

                            </li>
                            <br>
                            <b>Vencimiento Seguro:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->seguro_fecha); ?>

                            </li>
                            <br>
                            <b>Vencimiento Verificación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->verificacion_fecha); ?>

                            </li>
                            <br>
                            <?php if($unidade->tipomantenimiento == 'Fecha'): ?>
                                <b>Tipo de Mantenimiento:</b>
                                <li class="list-group-item">
                                    Mantenimiento por Fecha de Vencimiento
                                </li>
                                <br>
                                <b>Vencimiento Mantenimiento:</b>
                                <li class="list-group-item">
                                    <?php echo e($unidade->mantenimiento_fecha); ?>

                                </li>
                                <br>
                            <?php endif; ?>
                            <?php if($unidade->tipomantenimiento == 'Kilometraje'): ?>
                                
                                <b>Tipo de Mantenimiento:</b>
                                <li class="list-group-item">
                                    Mantenimiento por Kilometraje
                                </li>
                                <br>
                                <b>Vencimiento Mantenimiento:</b>
                                <li class="list-group-item">
                                    
                                </li>
                                <br>
                            <?php endif; ?>
                            <b>Vencimiento Fumigación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->lapsofumigacion); ?>

                            </li>
                            <br>
                            <b>Status:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->status); ?>

                            </li>
                            <br>
                            <b>Cliente:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cliente); ?>

                            </li>
                            <br>
                        <?php endif; ?>
                        <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                            <b>Codigo Postal:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cp); ?>

                            </li>
                            <br>
                            <b>Dirección:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->direccion); ?>

                            </li>
                            <br>
                            <b>Calle:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->calle); ?>

                            </li>
                            <br>
                            <b>Ciudad:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->ciudad); ?>

                            </li>
                            <br>
                            <b>Responsable:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->responsable); ?>

                            </li>
                            <br>
                            <b>Vencimiento Fumigación:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->lapsofumigacion); ?>

                            </li>
                            <br>
                            <b>Cliente:</b>
                            <li class="list-group-item">
                                <?php echo e($unidade->cliente); ?>

                            </li>
                            <br>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e($a); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="delete<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar la
                                <?php if($unidade->tipo == 'Unidad Habitacional o Comercial'): ?>
                                    Vivienda <?php echo e($unidade->direccion); ?>

                                <?php endif; ?>
                                <?php if($unidade->tipo == 'Unidad Vehicular'): ?>
                                    Unidad <?php echo e($unidade->serieunidad); ?>

                                <?php endif; ?>
                                ?
                            </b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('unidades.destroy', $unidade->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            $a = $a . 'a';
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/reportes/vambiental.blade.php ENDPATH**/ ?>