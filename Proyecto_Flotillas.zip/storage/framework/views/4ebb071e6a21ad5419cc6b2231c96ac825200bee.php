<?php
    $cliente = strval($_POST['datos_unidad']);
    $cadena_1 = '
    <label for="filtrounid">Filtro Unidades</label>
        <select name="filtrounid" id="filtrounid" class=" selectsearch" style="width:80%">
            <option selected value="todos">Todas Las Unidades</option>
            <option value="'. $cliente .'">'. $cliente .'</option>
            ';
    use App\Models\Unidade;
    $unidad = Unidade::where('cliente', '=', $cliente)
        ->where('tipo', '=', 'Unidad Vehicular')
        ->get();
    foreach ($unidad as $unidade) {
        $cadena_1 = $cadena_1 . '<option disabled selected value="todos">SI ENTTRO</option>';
        $cadena_1 = $cadena_1 . '<option value="' . $unidade->id . '">' . strval($unidade->serieunidad) . '</option>';
    }
    $cadena_1 = $cadena_1 . '</select>';
    echo $cadena_1;
?>
<?php /**PATH C:\laragon\www\Flotillas\resources\views/pdf/datos_unidades.blade.php ENDPATH**/ ?>