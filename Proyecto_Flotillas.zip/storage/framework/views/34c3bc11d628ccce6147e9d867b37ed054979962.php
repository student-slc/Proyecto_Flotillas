

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Usuarios</h3>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-lg-12  col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-md" style="background-color: #7caa98"
                                href="<?php echo e(route('usuarios.create')); ?>">Nuevo</a>
                            <br>
                            <br>

                                <table id="tablas-style" class="table">
                                    <thead  style="background-color:#95b8f6">
                                        <th style="display: none;">ID</th>
                                        <th style="color:#fff;">Nombre</th>
                                        <th style="color:#fff;">Cliente</th>
                                        <th style="color:#fff;">E-mail</th>
                                        <th style="color:#fff;">Rol</th>
                                        <th style="color:#fff;">Acciones</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $a = 'a';
                                        ?>
                                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="display: none;"><?php echo e($usuario->id); ?></td>
                                                <td><?php echo e($usuario->name); ?></td>
                                                <td><?php echo e($usuario->clientes); ?></td>
                                                <td><?php echo e($usuario->email); ?></td>
                                                <td>
                                                    <?php if(!empty($usuario->getRoleNames())): ?>
                                                        <?php $__currentLoopData = $usuario->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolNombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <h5><span class="badge bg-sm badge bg-dark"><?php echo e($rolNombre); ?></span>
                                                            </h5>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <a class="btn btn-sm" style="background-color: #9dbad5"
                                                        href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>">
                                                        <i class="fas fa-pencil-alt"></i></a>
                                                    <button type="submit" class="btn btn-sm" style="background-color: #ff8097"
                                                        onclick="$('#delete<?php echo e($a); ?>').modal('show')">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php
                                                $a = $a . 'a';
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <!-- Centramos la paginacion a la derecha
                                <div class="pagination justify-content-end">
                                   
                                </div> -->

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php
        $a = 'a';
    ?>
    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="modal fade" id="delete<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar al usuario <?php echo e($usuario->name); ?>?
                            </b></h5>
                        <button type="button" class="btn-close" onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            $a = $a . 'a';
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/usuarios/index.blade.php ENDPATH**/ ?>