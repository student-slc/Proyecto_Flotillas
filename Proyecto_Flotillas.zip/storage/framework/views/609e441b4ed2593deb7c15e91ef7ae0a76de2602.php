<?php $__env->startSection('title'); ?>
    Clientes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Clientes</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-warning" href="<?php echo e(route('clientes.create')); ?>">Nuevo</a>
                            <table class="table table-striped mt-2" id="tabla">
                                <a class="btn btn-success" href="<?php echo e(route('clientes.export')); ?>"><i
                                        class="fas fa-file-excel"></i></a>
                                <input type="text" class="form-control pull-right" style="width:20%" id="search"
                                    placeholder="Buscar....">
                                <thead style="background-color:#6777ef">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Nombre Cliente</th>
                                    <th style="color:#fff;">Información completa</th>
                                    <th style="color:#fff;">Unidades</th>
                                    <th style="color:#fff;">Operadores</th>
                                    <th style="color:#fff;">Status de Servicio</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($cliente->id); ?></td>
                                            <td><?php echo e($cliente->nombrecompleto); ?></td>
                                            
                                            <td>
                                                <button type="button" class="btn btn-primary"
                                                    onclick="$('#<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('show')">
                                                    Detalles
                                                </button>
                                            </td>
                                            
                                            <td>
                                                <a class="btn btn-dark"
                                                    href="<?php echo e(route('clientes.show', $usuario = $cliente->nombrecompleto)); ?>">
                                                    <i class="fas fa-bus"></i>
                                                </a>
                                            </td>
                                            <td>
                                                <a class="btn btn-dark"
                                                    href="<?php echo e(route('operadores.show', $usuario = $cliente->nombrecompleto)); ?>">
                                                    <i class="fas fa-address-card"></i>
                                                </a>
                                            </td>
                                            <td>
                                                <?php if($cliente->statuspago == 'Sin Servicio'): ?>
                                                    <h5><span class="badge badge-dark"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'Por Confirmar'): ?>
                                                    <h5><span class="badge badge-warning"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'En Ejecucion'): ?>
                                                    <h5><span class="badge badge-primary"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'No Pagado'): ?>
                                                    <h5><span class="badge badge-danger"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'Pagado'): ?>
                                                    <h5><span class="badge badge-success"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-info" href="<?php echo e(route('clientes.edit', $cliente->id)); ?>">
                                                    <i class="fas fa-edit"></i></a>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="$('#delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('show')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>Informacion de
                                <?php echo e($cliente->nombrecompleto); ?></b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <h5 style="text-align: center">Datos de Personales</h5>
                        <b>Telefono:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->telefono); ?>

                        </li>
                        <br>
                        <b>Correo:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->correo); ?>

                        </li>
                        <br>
                        <b>Dirección:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->direccionfisica); ?>

                        </li>
                        <br>
                        <b>Municipio:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->municipio); ?>

                        </li>
                        <br>
                        <b>Clonia:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->colonia); ?>

                        </li>
                        <br>
                        <b>Estado:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->estado); ?>

                        </li>
                        <br>
                        <b>CP:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->codigopostal); ?>

                        </li>
                        <br>
                        <h5 style="text-align: center">Datos de Facturación</h5>
                        <b>RFC:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->rfc); ?>

                        </li>
                        <br>
                        <b>Razon Social:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->razonsocial); ?>

                        </li>
                        <br>
                        <b>Numero:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->numero); ?>

                        </li>
                        <br>
                        <b>Regimen Fiscal:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->regimen_fiscal); ?>

                        </li>
                        <br>
                        <b>SFDI:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->sfdi); ?>

                        </li>
                        <br>
                        <b>Observaciones:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->observaciones); ?>

                        </li>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>" tabindex="-1"
            role="dialog" aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar al Cliente
                                <?php echo e($cliente->nombrecompleto); ?>?</b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/clientes/index.blade.php ENDPATH**/ ?>