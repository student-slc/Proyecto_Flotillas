
<?php $__env->startSection('title'); ?>
    Clientes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Clientes</h3>
        </div>
        <div class="section-body">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general-rol')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('clientes.create')); ?>">Nuevo</a>
                            <?php endif; ?>
                            <table id='tablas-style' class="table table-striped mt-2">
                                
                                
                                <br>
                                <br>
                                <thead style="background-color:#95b8f6">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Nombre Cliente
                                    </th>
                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona los detalles del cliente y datos de facturación">
                                            Información completa
                                        </div>
                                    </th>
                                    <th style="color:#fff;">Unidades</th>
                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona información de los operadores, licencia y certificado médico">
                                            Operadores
                                        </div>

                                    </th>
                                    <th style="color:#fff;">
                                        <div data-toggle="tooltip" data-placement="top"
                                            title="Proporciona el estado de pago ">
                                            Status de Servicio
                                        </div>
                                    </th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general-rol')): ?>
                                        <th style="color:#fff;">Acciones</th>
                                    <?php endif; ?>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($cliente->id); ?></td>
                                            <td><?php echo e($cliente->nombrecompleto); ?></td>
                                            
                                            <td>
                                                <button type="button" class="btn btn-sm text-dark"
                                                    style="background-color: #9dbad5"
                                                    onclick="$('#<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('show')">
                                                    Detalles
                                                </button>
                                            </td>
                                            
                                            <td>
                                                <a class="btn btn-sm" style="background-color: #7caa98"
                                                    href="<?php echo e(route('clientes.show', $usuario = $cliente->nombrecompleto)); ?>">
                                                    <i class="fas fa-bus"></i>
                                                </a>
                                            </td>
                                            <td>
                                                <a class="btn btn-sm" style="background-color: #7caa98"
                                                    href="<?php echo e(route('operadores.show', $usuario = $cliente->nombrecompleto)); ?>">
                                                    <i class="fas fa-address-card"></i>
                                                </a>
                                            </td>
                                            <td>
                                                <?php if($cliente->statuspago == 'Sin Servicio'): ?>
                                                    <h5><span class="badge badge-dark"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'Por Confirmar'): ?>
                                                    <h5><span class="badge badge-warning"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'En Ejecucion'): ?>
                                                    <h6><span class="badge badge-primary"><?php echo e($cliente->statuspago); ?></span>
                                                    </h6>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'No Pagado'): ?>
                                                    <h5><span
                                                            class="badge badge-pill badge-danger"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                                <?php if($cliente->statuspago == 'Pagado'): ?>
                                                    <h5><span class="badge badge-success"><?php echo e($cliente->statuspago); ?></span>
                                                    </h5>
                                                <?php endif; ?>
                                            </td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general-rol')): ?>
                                                <td>

                                                    <a class="btn btn-sm" style="background-color: #9dbad5"
                                                        href="<?php echo e(route('clientes.edit', $cliente->id)); ?>">
                                                        <i class="fas fa-pencil-alt"></i></a>
                                                    <button type="submit" class="btn btn-sm" style="background-color: #ff8097"
                                                        onclick="$('#delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('show')">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>Informacion de
                                <?php echo e($cliente->nombrecompleto); ?></b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <h5 style="text-align: center">Datos de Personales</h5>
                        <b>Telefono:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->telefono); ?>

                        </li>
                        <br>
                        <b>Correo:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->correo); ?>

                        </li>
                        <br>
                        <b>Dirección:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->direccionfisica); ?>

                        </li>
                        <br>
                        <b>Municipio:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->municipio); ?>

                        </li>
                        <br>
                        <b>Clonia:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->colonia); ?>

                        </li>
                        <br>
                        <b>Estado:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->estado); ?>

                        </li>
                        <br>
                        <b>CP:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->codigopostal); ?>

                        </li>
                        <br>
                        <h5 style="text-align: center">Datos de Facturación</h5>
                        <b>RFC:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->rfc); ?>

                        </li>
                        <br>
                        <b>Razon Social:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->razonsocial); ?>

                        </li>
                        <br>
                        <b>Numero:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->numero); ?>

                        </li>
                        <br>
                        <b>Regimen Fiscal:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->regimen_fiscal); ?>

                        </li>
                        <br>
                        <b>SFDI:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->sfdi); ?>

                        </li>
                        <br>
                        <b>Servicios Para Este Cliente:</b>
                        <div class="card-deck">
                            <div class="card">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Si"
                                        <?php if($cliente->servicio_seguro == 'Si'): ?> checked <?php endif; ?> id="servicio_seguro"
                                        name="servicio_seguro">
                                    <label class="form-check-label" for="servicio_seguro">
                                        SEGURO
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Si"
                                        <?php if($cliente->servicio_ambiental == 'Si'): ?> checked <?php endif; ?> id="servicio_ambiental"
                                        name="servicio_ambiental">
                                    <label class="form-check-label" for="servicio_ambiental">
                                        V. AMBIENTAL
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Si"
                                        <?php if($cliente->servicio_fisica == 'Si'): ?> checked <?php endif; ?> id="servicio_fisica"
                                        name="servicio_fisica">
                                    <label class="form-check-label" for="servicio_fisica">
                                        V. FISICA
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Si"
                                        <?php if($cliente->servicio_mantenimiento == 'Si'): ?> checked <?php endif; ?> id="servicio_mantenimiento"
                                        name="servicio_mantenimiento">
                                    <label class="form-check-label" for="servicio_mantenimiento">
                                        MANTENIMIENTO
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Si"
                                        <?php if($cliente->servicio_fumigacion == 'Si'): ?> checked <?php endif; ?> id="servicio_fumigacion"
                                        name="servicio_fumigacion">
                                    <label class="form-check-label" for="servicio_fumigacion">
                                        FUMIGACION
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Si"
                                    <?php if($cliente->servicio_omedico == 'Si'): ?> checked <?php endif; ?>
                                        id="servicio_omedico" name="servicio_omedico">
                                    <label class="form-check-label" for="servicio_omedico">
                                        MEDICO OPERADOR
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="Si"
                                    <?php if($cliente->servicio_olicencia == 'Si'): ?> checked <?php endif; ?>
                                        id="servicio_olicencia" name="servicio_olicencia">
                                    <label class="form-check-label" for="servicio_olicencia">
                                        LICENCIA OPERADOR
                                    </label>
                                </div>
                            </div>
                        </div>
                        <br>
                        <b>Observaciones:</b>
                        <li class="list-group-item">
                            <?php echo e($cliente->observaciones); ?>

                        </li>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>" tabindex="-1"
            role="dialog" aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar al Cliente
                                <?php echo e($cliente->nombrecompleto); ?>?</b></h5>
                        <button type="button" class="btn-close"
                            onclick="$('#delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e(str_replace(' ', '', $cliente->nombrecompleto)); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <script>
                function tutorial() {
                    introJs().setOptions({
                        nextLabel: 'Siguiente',
                        prevLabel: 'Anterior',
                        doneLabel: 'Terminar',
                        skipLabel: 'Omitir',
                        steps: [{
                                element: document.querySelector('#status'),
                                intro: '<h3>Filtro estado</h3>Filtrar por estado de ticket (Abierto,En proceso, Cerrado,Etc)',
                                position: 'top'
                            },
                            {
                                element: document.querySelector('#type'),
                                intro: '<h3>Filtro tipo de ticket</h3>Filtrar por tipo de ticket (Preventivo,Correctivo y Modificaciones)',
                                position: 'top'
                            },
                            {
                                element: document.querySelector('#ticketsIndexDataTable_length'),
                                intro: '<h3>Selector de registros</h3>Seleccionar cuantos registros quieres mostrar',
                                position: 'top'
                            },
                            {
                                element: document.querySelector('#ticketsIndexDataTable_filter'),
                                intro: '<h3>Buscador</h3>Buscar por palabra en especifico',
                                position: 'top'
                            },
                            {
                                element: document.querySelector('#ticketsIndexDataTable_paginate'),
                                intro: '<h3>Paginacion</h3>Gestionar paginas de registros',
                                position: 'top'
                            }


                        ]
                    }).start();
                }
            </script>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/clientes/index.blade.php ENDPATH**/ ?>