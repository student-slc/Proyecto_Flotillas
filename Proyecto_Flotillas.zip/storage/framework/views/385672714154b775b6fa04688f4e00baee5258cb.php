<?php $__env->startSection('title'); ?>
    Verificaciones
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <?php
                use App\Models\Unidade;
                $todo = Unidade::where('serieunidad', '=', $unidad)->get();
                foreach ($todo as $todos) {
                    $placas = $todos->placas;
                }
            ?>
            <h3 class="page__heading">Verificaciones Ambientales de: <?php echo e($unidad); ?> / <?php echo e($placas); ?></h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="card-body">
                    <a class="btn btn-danger" href="<?php echo e(route('clientes.show', $usuario = $unidad)); ?>">Regresar</a>
                </div>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-warning" href="<?php echo e(route('verificaciones.crear', $unidad)); ?>">Nuevo</a>
                            <table id='tablas-style' class="table table-striped mt-2">
                               
                                
                                <br><br>
                                <thead style="background-color: #9dbad5">
                                    <th style="display: none;">ID</th>
                                    <th style="color:#fff;">Identificador</th>
                                    <th style="color:#fff;">Información</th>
                                    <th style="color:#fff;">Status</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php
                                        $a = 'a';
                                    ?>
                                    <?php $__currentLoopData = $verificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verificacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($verificacione->id); ?></td>
                                            <td><?php echo e($verificacione->noverificacion); ?></td>
                                            
                                            <td>
                                                <button type="button" class="btn btn-sm" style="background-color: #9dbad5"
                                                    onclick="$('#<?php echo e($a); ?>').modal('show')">
                                                    Detalles
                                                </button>
                                            </td>
                                            
                                            <td>
                                                <?php if($verificacione->estado == 'Activo'): ?>
                                                    <h5><span class="badge badge-success">Activo</span>
                                                    </h5>
                                                <?php else: ?>
                                                    <h5><span class="badge badge-danger">Inactivo</span>
                                                    </h5>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-sm" style="background-color: #9dbad5"
                                                    href="<?php echo e(route('verificaciones.edit', $verificacione->id)); ?>">
                                                    <i class="fas fa-pencil-alt"></i></a>
                                                <button type="submit" class="btn btn-sm"  class="btn btn-sm" style="background-color: #ff8097"
                                                    onclick="$('#delete<?php echo e($a); ?>').modal('show')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php
                                            $a = $a . 'a';
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <!-- Ubicamos la paginacion a la derecha -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php
        $a = 'a';
    ?>
    <?php $__currentLoopData = $verificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verificacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e($a); ?>" tabindex="-1" role="dialog" aria-labelledby="ModalDetallesTitle"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle"><b>Informacion de
                                <?php echo e($verificacione->noverificacion); ?></b></h5>
                        <button type="button" class="btn-close" onclick="$('#<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <div class="modal-body">
                        <b>Fecha de Vencimiento:</b>
                        <li class="list-group-item">
                            <?php echo e($verificacione->fechavencimiento); ?>

                        </li>
                        <br>
                        <b>Tipo de Verificación:</b>
                        <li class="list-group-item">
                            <?php echo e($verificacione->tipoverificacion); ?>

                        </li>
                        <br>
                        <b>Sub Tipo de Verificación</b>
                        <li class="list-group-item">
                            <?php echo e($verificacione->subtipoverificacion); ?>

                        </li>
                        <br>
                        <b>Ultima Verificación</b>
                        <li class="list-group-item">
                            <?php echo e($verificacione->ultimaverificacion); ?>

                        </li>
                        <br>
                        <b>Archivo Escaneado:</b>
                        <li class="list-group-item">
                            <object type="application/pdf" data="<?php echo e(asset($verificacione->caratulaverificacion)); ?>"
                                style="width: 400px; height: 300px;">
                                ERROR (no puede mostrarse el objeto)
                            </object>
                        </li>
                        <br>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger"
                            onclick="$('#<?php echo e($a); ?>').modal('hide')">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="delete<?php echo e($a); ?>" tabindex="-1" role="dialog"
            aria-labelledby="ModalDetallesTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalDetallesTitle" style="text-align: center"><b>¿Estas Seguro de
                                Eliminar la Verificación
                                <?php echo e($verificacione->id); ?>?</b></h5>
                        <button type="button" class="btn-close" onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                    </div>
                    <form action="<?php echo e(route('verificaciones.destroy', $verificacione->id, $unidad)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-footer">
                            <div class="container-fluid h-100">
                                <div class="row w-100 align-items-center ">
                                    <div class="col text-center">
                                        <button type="button" class="btn btn-danger"
                                            onclick="$('#delete<?php echo e($a); ?>').modal('hide')">
                                            NO</button>
                                        <button type="submit" class="btn btn-success">
                                            SI</i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            $a = $a . 'a';
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Flotillas\resources\views/verificaciones/index.blade.php ENDPATH**/ ?>