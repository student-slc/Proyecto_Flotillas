<b>Cliente:</b>
<li class="list-group-item">
    hola
</li>
<br>
{{-- @php
    $id_unidad = strval($_POST['id_unidad']);
    $estado = strval($_POST['estado']);
    $tipoverificacion = strval($_POST['tipoverificacion']);
    $noverificacion = strval($_POST['noverificacion']);
    $subtipoverificacion = strval($_POST['subtipoverificacion']);
    $ultimaverificacion = strval($_POST['ultimaverificacion']);
    $fechavencimiento = strval($_POST['fechavencimiento']);
@endphp --}}
{{-- ========================================= OCULTOS ========================================= --}}
{{-- <div class="col-xs-12 col-sm-12 col-md-12" hidden>
    <div class="form-group">
        <label for="id_unidad">id_unidad</label>
        <input type="text" name="id_unidad" id="id_unidad" class="form-control" value="{{ $id_unidad }}">
    </div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12" hidden>
    <div class="form-group">
        <label for="estado">estado</label>
        <input type="text" name="estado" id="estado" class="form-control" value="{{ $estado }}">
    </div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12" hidden>
    <div class="form-group">
        <label for="tipoverificacion">Tipo de Verificación</label>
        <input type="text" name="tipoverificacion" id="tipoverificacion" class="form-control"
            value="{{ $tipoverificacion }}">
    </div>
</div> --}}
{{-- ========================================================================= --}}
{{-- <div class="col-xs-12 col-sm-12 col-md-12">
    <div class="form-group">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <label for="noverificacion">Folio De Verificación</label>
                <input type="text" name="noverificacion" id="noverificacion" class="form-control"
                    value="{{ $noverificacion }}">
            </div>
        </div>
    </div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">
    <div class="form-group">
        <label for="subtipoverificacion">Sub Tipo de Verificación</label>
        <input type="text" name="subtipoverificacion" id="subtipoverificacion" class="form-control"
            value="{{ $subtipoverificacion }}">
    </div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">
    <div class="form-group">
        <label for="ultimaverificacion">Fecha Ultima Verificación</label>
        <input type="date" name="ultimaverificacion" id="ultimaverificacion" class="form-control"
            value="{{ $ultimaverificacion }}">
    </div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">
    <div class="form-group">
        <label for="fechavencimiento">Fecha de Vencimiento</label>
        <input type="date" name="fechavencimiento" id="fechavencimiento" class="form-control"
            min="{{ $fechavencimiento }}">
    </div>
</div>
 --}}
